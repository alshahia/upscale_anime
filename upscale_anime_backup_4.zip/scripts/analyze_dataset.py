#!/usr/bin/env python
"""
Dataset Analysis Tool

Preview auto-detected crop sizes, quality distribution, and recommended degradation settings
before starting training.

Usage:
    python scripts/analyze_dataset.py --config configs/auto_stage_pipeline.yaml
    python scripts/analyze_dataset.py --dir data/anime_video_frames --auto-crop
    python scripts/analyze_dataset.py --dir data/anime_video_frames --quality-analysis
"""
import argparse
import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / "src"))

# Direct imports to avoid __init__.py import chain
import importlib.util
spec = importlib.util.spec_from_file_location(
    "quality_analyzer", project_root / "src" / "data" / "quality_analyzer.py"
)
quality_analyzer_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(quality_analyzer_module)

QualityAnalyzer = quality_analyzer_module.QualityAnalyzer
analyze_dataset_quality = quality_analyzer_module.analyze_dataset_quality
compute_optimal_crop_size = quality_analyzer_module.compute_optimal_crop_size
get_degradation_preset_config = quality_analyzer_module.get_degradation_preset_config


def analyze_directory(
    dir_path: Path,
    auto_crop: bool = True,
    quality_analysis: bool = True,
    scale: int = 4,
    verbose: bool = False
):
    """Analyze a dataset directory and print statistics."""
    
    if not dir_path.exists():
        print(f"Error: Directory not found: {dir_path}")
        return False
    
    # Find images
    image_paths = (
        sorted(dir_path.glob("*.png")) +
        sorted(dir_path.glob("*.jpg")) +
        sorted(dir_path.glob("*.jpeg"))
    )
    
    if not image_paths:
        print(f"Error: No images found in {dir_path}")
        return False
    
    print(f"\n{'='*60}")
    print(f"Dataset Analysis: {dir_path.name}")
    print(f"{'='*60}")
    print(f"Total images: {len(image_paths)}")
    
    # Analyze image dimensions
    print(f"\n--- Image Dimensions ---")
    from PIL import Image
    
    dimensions = []
    for path in image_paths[:20] if not verbose else image_paths:
        try:
            with Image.open(path) as img:
                dimensions.append(img.size)
        except Exception as e:
            if verbose:
                print(f"  Warning: Could not read {path.name}: {e}")
    
    if dimensions:
        widths = [d[0] for d in dimensions]
        heights = [d[1] for d in dimensions]
        
        print(f"  Sampled: {len(dimensions)} images")
        print(f"  Width: min={min(widths)}, max={max(widths)}, avg={sum(widths)//len(widths)}")
        print(f"  Height: min={min(heights)}, max={max(heights)}, avg={sum(heights)//len(heights)}")
        
        # Show unique resolutions
        unique_dims = sorted(set(dimensions))
        print(f"  Unique resolutions: {len(unique_dims)}")
        for dim in unique_dims[:5]:
            count = dimensions.count(dim)
            print(f"    {dim[0]}x{dim[1]}: {count} images")
        if len(unique_dims) > 5:
            print(f"    ... and {len(unique_dims) - 5} more")
    
    # Auto crop size analysis
    if auto_crop:
        print(f"\n--- Auto Crop Size Detection ---")
        
        for mode in ['manual', 'auto']:
            crop_size = compute_optimal_crop_size(
                image_paths,
                mode=mode,
                manual_size=128 if mode == 'manual' else None,
                max_size=960,
                min_size=64
            )
            mode_label = "Fixed (default 128)" if mode == 'manual' else "Auto-detected"
            print(f"  {mode_label}: crop_size = {crop_size}")
        
        # Show recommendation
        recommended = compute_optimal_crop_size(
            image_paths, mode='auto', max_size=960, min_size=64
        )
        print(f"\n  Recommendation: Use crop_size_mode='auto' for crop_size={recommended}")
    
    # Quality analysis
    if quality_analysis:
        print(f"\n--- Quality Analysis ---")
        print(f"  Analyzing sample of images for quality metrics...")
        
        stats = analyze_dataset_quality(image_paths, sample_size=30)
        
        if 'error' in stats:
            print(f"  Error: {stats['error']}")
            return False
        
        print(f"  Mean quality score: {stats['mean_quality']:.3f} (0=low, 1=high)")
        print(f"  Quality range: {stats['min_quality']:.3f} - {stats['max_quality']:.3f}")
        print(f"  Std deviation: {stats['std_quality']:.3f}")
        
        # Tier distribution
        tiers = stats['tier_distribution']
        print(f"\n  Quality tier distribution:")
        print(f"    HD/Clean (quality > 0.8):     {tiers['hd_clean']} images ({tiers['hd_clean']/tiers['total_analyzed']*100:.1f}%)")
        print(f"    Standard (quality 0.5-0.8):   {tiers['standard']} images ({tiers['standard']/tiers['total_analyzed']*100:.1f}%)")
        print(f"    Low/Compressed (quality <0.5): {tiers['low_compressed']} images ({tiers['low_compressed']/tiers['total_analyzed']*100:.1f}%)")
        
        # Degradation recommendation
        recommended_preset = stats['recommended_preset']
        print(f"\n  Recommended degradation mode: '{recommended_preset}'")
        
        # Show preset details
        preset_config = get_degradation_preset_config(recommended_preset)
        if 'blur_prob' in preset_config:
            print(f"    Blur probability: {preset_config['blur_prob']}")
            print(f"    Noise probability: {preset_config['noise_prob']}")
            print(f"    JPEG probability: {preset_config['jpeg_prob']}")
        
        # Config recommendation
        print(f"\n  Configuration recommendation:")
        print(f"    degradation:")
        print(f"      enabled: true")
        print(f"      mode: \"{recommended_preset}\"")
        
        if stats['mean_quality'] > 0.8:
            print(f"\n    Note: Dataset appears to be high quality (HD/clean source).")
            print(f"          Light degradation is recommended to preserve details.")
        elif stats['mean_quality'] < 0.5:
            print(f"\n    Note: Dataset appears to be compressed/low quality.")
            print(f"          Heavy degradation will simulate realistic LR conditions.")
    
    print(f"\n{'='*60}\n")
    return True


def main():
    parser = argparse.ArgumentParser(
        description="Analyze dataset and preview auto-detected settings",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic analysis with auto-crop and quality analysis
  python scripts/analyze_dataset.py --dir data/anime_video_frames
  
  # Only auto-crop analysis
  python scripts/analyze_dataset.py --dir data/anime_video_frames --auto-crop --no-quality
  
  # Only quality analysis
  python scripts/analyze_dataset.py --dir data/anime_video_frames --quality-analysis --no-crop
  
  # Verbose output (analyze all images)
  python scripts/analyze_dataset.py --dir data/anime_video_frames --verbose
        """
    )
    
    parser.add_argument(
        '--dir', '-d',
        type=str,
        required=True,
        help='Path to dataset directory containing images'
    )
    
    parser.add_argument(
        '--scale', '-s',
        type=int,
        default=4,
        help='Upscaling factor (default: 4)'
    )
    
    parser.add_argument(
        '--auto-crop',
        dest='auto_crop',
        action='store_true',
        default=True,
        help='Analyze optimal crop size (default: enabled)'
    )
    
    parser.add_argument(
        '--no-crop',
        dest='auto_crop',
        action='store_false',
        help='Disable auto-crop analysis'
    )
    
    parser.add_argument(
        '--quality-analysis', '-q',
        dest='quality_analysis',
        action='store_true',
        default=True,
        help='Analyze image quality and recommend degradation (default: enabled)'
    )
    
    parser.add_argument(
        '--no-quality',
        dest='quality_analysis',
        action='store_false',
        help='Disable quality analysis'
    )
    
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Verbose output (analyze all images, not just sample)'
    )
    
    args = parser.parse_args()
    
    dir_path = Path(args.dir)
    
    success = analyze_directory(
        dir_path,
        auto_crop=args.auto_crop,
        quality_analysis=args.quality_analysis,
        scale=args.scale,
        verbose=args.verbose
    )
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
