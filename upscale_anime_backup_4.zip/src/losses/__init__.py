from losses.pixel_loss import L1Loss, L2Loss, CharbonnierLoss, LossFactory
from losses.wavelet_loss import WaveletLoss, DirectionalWaveletLoss
from losses.perceptual_loss import VGGPerceptualLoss, ResNetPerceptualLoss, DISTSLoss, PerceptualLossFactory
from losses.adversarial_loss import (
    AdversarialLoss,
    VanillaGANLoss,
    RelativisticGANLoss,
    HingeGANLoss,
    SRDiscriminator,
    GANTrainer,
    create_adversarial_loss,
    create_discriminator,
)
from losses.gradient_loss import GradientLoss, LaplacianLoss, CombinedGradientLoss
from losses.diversity_loss import TeacherDiversityLoss, TeacherDisagreementLoss, TeacherConsistencyLoss
from losses.combined_loss import Stage1CombinedLoss, AdaptiveCombinedLoss
from losses.anime_losses import (
    LineArtPreservationLoss,
    ColorConsistencyLoss,
    FlatRegionPreservationLoss,
    AnimeCombinedLoss,
)
from losses.temporal_loss import TemporalConsistencyLoss, FlowGuidedTemporalLoss, VideoAwareLoss

__all__ = [
    # Pixel losses
    'L1Loss',
    'L2Loss',
    'CharbonnierLoss',
    'LossFactory',
    # Wavelet losses
    'WaveletLoss',
    'DirectionalWaveletLoss',
    # Perceptual losses
    'VGGPerceptualLoss',
    'ResNetPerceptualLoss',
    'DISTSLoss',
    'PerceptualLossFactory',
    # Adversarial losses
    'AdversarialLoss',
    'VanillaGANLoss',
    'RelativisticGANLoss',
    'HingeGANLoss',
    'SRDiscriminator',
    'GANTrainer',
    'create_adversarial_loss',
    'create_discriminator',
    # Gradient losses
    'GradientLoss',
    'LaplacianLoss',
    'CombinedGradientLoss',
    # Diversity losses
    'TeacherDiversityLoss',
    'TeacherDisagreementLoss',
    'TeacherConsistencyLoss',
    # Combined losses
    'Stage1CombinedLoss',
    'AdaptiveCombinedLoss',
    # Anime-specific losses
    'LineArtPreservationLoss',
    'ColorConsistencyLoss',
    'FlatRegionPreservationLoss',
    'AnimeCombinedLoss',
    # Temporal losses
    'TemporalConsistencyLoss',
    'FlowGuidedTemporalLoss',
    'VideoAwareLoss',
]
