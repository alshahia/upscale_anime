"""
Base dataset class for Super-Resolution
Supports multiple datasets, degradation pipelines, and flexible data loading
Includes auto crop_size detection and smart quality-aware degradation
"""
import os
import random
import numpy as np
import torch
from torch.utils.data import Dataset
from pathlib import Path
from PIL import Image
import cv2
from typing import Optional, Tuple, List, Dict, Callable
import torchvision.transforms as transforms
import warnings

try:
    from src.data.quality_analyzer import (
        QualityAnalyzer, compute_optimal_crop_size, get_degradation_preset_config
    )
except ImportError:
    try:
        from data.quality_analyzer import (
            QualityAnalyzer, compute_optimal_crop_size, get_degradation_preset_config
        )
    except ImportError:
        from quality_analyzer import (
            QualityAnalyzer, compute_optimal_crop_size, get_degradation_preset_config
        )


class BaseDataset(Dataset):
    """
    Universal base dataset for Super-Resolution.
    Handles HR/LR image loading, degradation, and augmentation.
    """
    
    def __init__(
        self,
        hr_dir: str,
        lr_dir: Optional[str] = None,
        scale: int = 4,
        crop_size: int = 128,
        augment: bool = True,
        degradation: Optional[Dict] = None,
        preload: bool = False,
        max_images: Optional[int] = None,
        gpu_degradation: bool = False,
        # Auto crop_size parameters
        crop_size_mode: str = 'manual',  # 'auto' or 'manual'
        auto_crop_max: int = 960,
        auto_crop_min: int = 64,
        # Smart degradation parameters
        use_quality_analyzer: bool = False,
        quality_analyzer: Optional[QualityAnalyzer] = None,
    ):
        """
        Args:
            hr_dir: Directory with high-resolution images
            lr_dir: Directory with low-resolution images (optional)
            scale: Upsampling factor
            crop_size: Training patch size (HR space)
            augment: Enable random flip/rotate
            degradation: Degradation config for synthetic LR generation
            preload: Load all images into RAM
            max_images: Limit dataset size (for testing)
            crop_size_mode: 'auto' to detect from dataset, 'manual' to use crop_size
            auto_crop_max: Maximum crop size in auto mode (prevents OOM)
            auto_crop_min: Minimum crop size
            use_quality_analyzer: Enable per-image quality-based degradation
            quality_analyzer: Optional pre-configured QualityAnalyzer instance
        """
        super().__init__()
        
        self.hr_dir = Path(hr_dir)
        self.lr_dir = Path(lr_dir) if lr_dir else None
        self.scale = scale
        self.crop_size = crop_size
        self.augment = augment
        self.degradation = degradation or {}
        self.preload = preload
        
        # Validate directory exists
        if not self.hr_dir.exists():
            raise FileNotFoundError(
                f"HR directory does not exist: {self.hr_dir}\n"
                f"Please create the directory and add images, or update the config.\n"
                f"To create dummy test data, run:\n"
                f"  python -c \"from data.data_utils import create_dummy_dataset; "
                f"create_dummy_dataset('{self.hr_dir}', num_images=10)\""
            )
        
        # Get image list
        self.hr_images = sorted(self.hr_dir.glob("*.png")) + \
                         sorted(self.hr_dir.glob("*.jpg")) + \
                         sorted(self.hr_dir.glob("*.jpeg"))
        
        # Validate images found
        if len(self.hr_images) == 0:
            raise ValueError(
                f"No images found in {self.hr_dir}\n"
                f"Supported formats: .png, .jpg, .jpeg\n"
                f"To create dummy test data, run:\n"
                f"  python -c \"from data.data_utils import create_dummy_dataset; "
                f"create_dummy_dataset('{self.hr_dir}', num_images=10)\""
            )
        
        if max_images:
            self.hr_images = self.hr_images[:max_images]
        
        print(f"Dataset loaded: {len(self.hr_images)} images from {self.hr_dir}")
        
        # Auto-detect optimal crop size if enabled
        if crop_size_mode == 'auto':
            computed_crop = compute_optimal_crop_size(
                self.hr_images,
                mode='auto',
                max_size=auto_crop_max,
                min_size=auto_crop_min
            )
            if computed_crop != self.crop_size:
                print(f"[Auto Crop] Adjusted crop_size from {self.crop_size} to {computed_crop}")
                self.crop_size = computed_crop
        elif crop_size_mode == 'manual' and len(self.hr_images) > 0:
            # Warn if manual crop_size might be inappropriate for dataset
            self._validate_crop_size()
        
        # Initialize quality analyzer if enabled
        self.use_quality_analyzer = use_quality_analyzer
        self.quality_analyzer = quality_analyzer
        if use_quality_analyzer:
            if self.quality_analyzer is None:
                self.quality_analyzer = QualityAnalyzer()
            print(f"[Quality Analyzer] Enabled - per-image quality-based degradation")
            # Analyze dataset and recommend preset
            if self.degradation.get('mode') == 'auto':
                self._setup_auto_degradation()
        
        # Preload images if requested
        self.gpu_degradation = gpu_degradation
        
        self.cached_hr = {}
        if preload:
            for img_path in self.hr_images:
                self.cached_hr[img_path] = self._load_image(img_path)
        
        # Precompute LR paths if provided
        if self.lr_dir:
            self.lr_images = []
            for hr_path in self.hr_images:
                lr_name = hr_path.stem + f"_x{scale}" + hr_path.suffix
                lr_path = self.lr_dir / lr_name
                if lr_path.exists():
                    self.lr_images.append(lr_path)
                else:
                    # Try without suffix
                    lr_path = self.lr_dir / hr_path.name
                    if lr_path.exists():
                        self.lr_images.append(lr_path)
                    else:
                        self.lr_images.append(None)
        else:
            self.lr_images = [None] * len(self.hr_images)
    
    def _load_image(self, path: Path) -> np.ndarray:
        """Load image as numpy array [H, W, C], RGB, uint8"""
        try:
            img = cv2.imread(str(path), cv2.IMREAD_COLOR)
            if img is None:
                raise ValueError(f"Failed to load image: {path}")
            # Validate image dimensions
            if img.ndim != 3:
                raise ValueError(f"Invalid image dimensions (expected 3D, got {img.ndim}D): {path}")
            if img.shape[2] != 3:
                raise ValueError(f"Invalid number of channels (expected 3, got {img.shape[2]}): {path}")
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            return img
        except Exception as e:
            if isinstance(e, ValueError):
                raise
            raise ValueError(f"Error loading image {path}: {e}") from e
    
    def _validate_crop_size(self):
        """Validate that crop_size is appropriate for dataset images."""
        try:
            # Sample a few images to check dimensions
            sample_paths = self.hr_images[:5]
            min_h, min_w = float('inf'), float('inf')
            
            for path in sample_paths:
                with Image.open(path) as img:
                    w, h = img.size
                    min_h = min(min_h, h)
                    min_w = min(min_w, w)
            
            smallest_dim = min(min_h, min_w)
            
            if self.crop_size > smallest_dim:
                warnings.warn(
                    f"[BaseDataset] crop_size ({self.crop_size}) is larger than smallest image dimension "
                    f"({smallest_dim}). This will cause upscaling during training. "
                    f"Consider using crop_size_mode='auto' or setting crop_size to {smallest_dim // 2}. "
                    f"Dataset: {self.hr_dir}"
                )
        except Exception:
            # If validation fails, continue silently
            pass
    
    def _setup_auto_degradation(self):
        """Setup auto degradation based on dataset quality analysis."""
        try:
            print("[Auto Degradation] Analyzing dataset quality...")
            from src.data.quality_analyzer import analyze_dataset_quality
            
            stats = analyze_dataset_quality(self.hr_images, sample_size=30)
            
            if 'error' in stats:
                print(f"[Auto Degradation] Failed to analyze: {stats['error']}")
                return
            
            recommended = stats['recommended_preset']
            mean_quality = stats['mean_quality']
            
            print(f"[Auto Degradation] Mean quality: {mean_quality:.2f}")
            print(f"[Auto Degradation] Tier distribution: {stats['tier_distribution']}")
            print(f"[Auto Degradation] Recommended preset: '{recommended}'")
            
            # Apply preset
            preset_config = get_degradation_preset_config(recommended, self.degradation)
            self.degradation.update(preset_config)
            
            print(f"[Auto Degradation] Applied '{recommended}' preset")
            
        except Exception as e:
            print(f"[Auto Degradation] Error during setup: {e}")
    
    def _get_degradation_for_image(self, img: np.ndarray, img_path: Optional[Path] = None) -> Dict:
        """
        Get degradation config for a specific image based on quality.
        
        Returns:
            Degradation config dict appropriate for image quality tier
        """
        if not self.use_quality_analyzer or self.quality_analyzer is None:
            return self.degradation
        
        # Analyze image quality
        quality_score = self.quality_analyzer.analyze_image(img, img_path)
        tier = self.quality_analyzer.get_degradation_tier(quality_score)
        
        # Get preset for this tier
        tier_config = get_degradation_preset_config(tier, self.degradation)
        
        return tier_config
    
    def _apply_degradation_with_quality(self, img: np.ndarray, img_path: Optional[Path] = None) -> np.ndarray:
        """
        Apply degradation with quality-aware selection.
        
        Args:
            img: Input image
            img_path: Optional path for caching
            
        Returns:
            Degraded LR image
        """
        if not self.degradation.get('enabled', False):
            # Simple bicubic downsample
            h, w = img.shape[:2]
            lr_h, lr_w = h // self.scale, w // self.scale
            lr = cv2.resize(img, (lr_w, lr_h), interpolation=cv2.INTER_CUBIC)
            return lr
        
        # Get quality-aware degradation config
        if self.use_quality_analyzer:
            cfg = self._get_degradation_for_image(img, img_path)
        else:
            cfg = self.degradation
        
        # Apply first-order degradation with selected config
        img = self._apply_first_degradation_with_config(img, cfg)
        
        # Resize to LR size
        h, w = img.shape[:2]
        lr_h, lr_w = h // self.scale, w // self.scale
        img = cv2.resize(img, (lr_w, lr_h), interpolation=cv2.INTER_LINEAR)
        
        # Apply second-order degradation
        img = self._apply_second_degradation_with_config(img, cfg)
        
        return img
    
    def _apply_first_degradation_with_config(self, img: np.ndarray, cfg: Dict) -> np.ndarray:
        """Apply first-order degradation with specific config."""
        # Blur
        if random.random() < cfg.get('blur_prob', 0.7):
            kernel_sizes = cfg.get('blur_kernel_size', [7, 9, 11])
            kernel_size = random.choice(kernel_sizes)
            sigma_range = cfg.get('blur_sigma', [0.1, 3.0])
            sigma = random.uniform(*sigma_range[:2])
            img = self._apply_blur(img, kernel_size, sigma)
        
        # Noise
        if random.random() < cfg.get('noise_prob', 0.5):
            sigma_range = cfg.get('noise_sigma', [0, 25])
            sigma = random.uniform(*sigma_range[:2])
            img = self._apply_noise(img, sigma)
        
        # Random resize
        resize_probs = cfg.get('resize_prob', [0.2, 0.7, 0.1])
        resize_type = random.choices(['up', 'down', 'keep'], weights=resize_probs)[0]
        
        if resize_type != 'keep':
            h, w = img.shape[:2]
            resize_range = cfg.get('resize_range', [0.15, 1.5])
            
            if resize_type == 'up':
                factor = random.uniform(1.0, resize_range[1])
            else:
                factor = random.uniform(resize_range[0], 1.0)
            
            new_h, new_w = int(h * factor), int(w * factor)
            img = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        
        # JPEG compression
        if random.random() < cfg.get('jpeg_prob', 0.5):
            jpeg_qualities = cfg.get('jpeg_quality', [60, 70, 80, 90, 100])
            quality = random.choice(jpeg_qualities)
            img = self._apply_jpeg(img, quality)
        
        return img
    
    def _apply_second_degradation_with_config(self, img: np.ndarray, cfg: Dict) -> np.ndarray:
        """Apply second-order degradation with specific config."""
        # Use lower probabilities for second-order
        second_order_prob = cfg.get('second_order_prob', 0.3)
        
        if random.random() < second_order_prob:
            kernel_size = random.choice([3, 5, 7])
            sigma = random.uniform(0.1, 1.0)
            img = self._apply_blur(img, kernel_size, sigma)
        
        if random.random() < second_order_prob:
            sigma = random.uniform(0, 10)
            img = self._apply_noise(img, sigma)
        
        if random.random() < second_order_prob:
            jpeg_qualities = cfg.get('jpeg_quality', [70, 80, 90, 100])
            quality = random.choice(jpeg_qualities)
            img = self._apply_jpeg(img, quality)
        
        return img
    
    def _apply_degradation(self, img: np.ndarray) -> np.ndarray:
        """
        Apply RealESRGAN-style high-order degradation to create LR image.
        img: [H, W, C], RGB, uint8
        Returns: LR image at scale factor
        """
        if not self.degradation.get('enabled', False):
            # Simple bicubic downsample
            h, w = img.shape[:2]
            lr_h, lr_w = h // self.scale, w // self.scale
            lr = cv2.resize(img, (lr_w, lr_h), interpolation=cv2.INTER_CUBIC)
            return lr
        
        # First-order degradation
        img = self._first_degradation(img)
        
        # Resize to LR size
        h, w = img.shape[:2]
        lr_h, lr_w = h // self.scale, w // self.scale
        img = cv2.resize(img, (lr_w, lr_h), interpolation=cv2.INTER_LINEAR)
        
        # Second-order degradation
        img = self._second_degradation(img)
        
        return img
    
    def _first_degradation(self, img: np.ndarray) -> np.ndarray:
        """First-order degradation: blur, noise, resize, jpeg"""
        cfg = self.degradation
        
        # Blur
        if random.random() < cfg.get('blur_prob', 0.7):
            kernel_size = random.choice(cfg.get('blur_kernel_size', [7, 9, 11]))
            sigma = random.uniform(*cfg.get('blur_sigma', [0.1, 3.0])[:2])
            img = self._apply_blur(img, kernel_size, sigma)
        
        # Noise
        if random.random() < cfg.get('noise_prob', 0.5):
            sigma = random.uniform(*cfg.get('noise_sigma', [0, 25])[:2])
            img = self._apply_noise(img, sigma)
        
        # Random resize
        resize_probs = cfg.get('resize_prob', [0.2, 0.7, 0.1])
        resize_type = random.choices(['up', 'down', 'keep'], weights=resize_probs)[0]
        
        if resize_type != 'keep':
            h, w = img.shape[:2]
            resize_range = cfg.get('resize_range', [0.15, 1.5])
            
            if resize_type == 'up':
                factor = random.uniform(1.0, resize_range[1])
            else:
                factor = random.uniform(resize_range[0], 1.0)
            
            new_h, new_w = int(h * factor), int(w * factor)
            img = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        
        # JPEG compression
        if random.random() < cfg.get('jpeg_prob', 0.5):
            quality = random.choice(cfg.get('jpeg_quality', [60, 70, 80, 90, 100]))
            img = self._apply_jpeg(img, quality)
        
        return img
    
    def _second_degradation(self, img: np.ndarray) -> np.ndarray:
        """Second-order degradation (lighter)"""
        # Similar to first but with lower probabilities
        cfg = self.degradation
        
        if random.random() < 0.3:
            kernel_size = random.choice([3, 5, 7])
            sigma = random.uniform(0.1, 1.0)
            img = self._apply_blur(img, kernel_size, sigma)
        
        if random.random() < 0.3:
            sigma = random.uniform(0, 10)
            img = self._apply_noise(img, sigma)
        
        if random.random() < 0.3:
            quality = random.choice([70, 80, 90, 100])
            img = self._apply_jpeg(img, quality)
        
        return img
    
    def _apply_blur(self, img: np.ndarray, kernel_size: int, sigma: float) -> np.ndarray:
        """Apply Gaussian blur"""
        kernel = cv2.getGaussianKernel(kernel_size, sigma)
        kernel = kernel * kernel.T
        img = cv2.filter2D(img, -1, kernel)
        return img
    
    def _apply_noise(self, img: np.ndarray, sigma: float) -> np.ndarray:
        """Apply Gaussian noise"""
        if sigma == 0:
            return img
        noise = np.random.normal(0, sigma, img.shape).astype(np.float32)
        img = img.astype(np.float32) + noise
        img = np.clip(img, 0, 255).astype(np.uint8)
        return img
    
    def _apply_jpeg(self, img: np.ndarray, quality: int) -> np.ndarray:
        """Apply JPEG compression"""
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
        _, encimg = cv2.imencode('.jpg', img, encode_param)
        img = cv2.imdecode(encimg, 1)
        return img
    
    def _random_crop(self, hr: np.ndarray, lr: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Random crop paired patches"""
        hr_h, hr_w = hr.shape[:2]
        lr_h, lr_w = lr.shape[:2]
        
        # Ensure LR dimensions match expected scale
        expected_lr_h, expected_lr_w = hr_h // self.scale, hr_w // self.scale
        if lr_h != expected_lr_h or lr_w != expected_lr_w:
            # Resize LR to match expected dimensions
            lr = cv2.resize(lr, (expected_lr_w, expected_lr_h), interpolation=cv2.INTER_CUBIC)
            lr_h, lr_w = expected_lr_h, expected_lr_w
        
        # Check if crop size is valid
        if hr_h < self.crop_size or hr_w < self.crop_size:
            # Resize HR to crop_size if too small
            hr = cv2.resize(hr, (self.crop_size, self.crop_size), interpolation=cv2.INTER_CUBIC)
            lr = cv2.resize(lr, (self.crop_size // self.scale, self.crop_size // self.scale), 
                           interpolation=cv2.INTER_CUBIC)
            return hr, lr
        
        # Random crop position
        top = random.randint(0, hr_h - self.crop_size)
        left = random.randint(0, hr_w - self.crop_size)
        
        # Crop HR
        hr_crop = hr[top:top + self.crop_size, left:left + self.crop_size]
        
        # Crop LR at corresponding position
        lr_top = top // self.scale
        lr_left = left // self.scale
        lr_crop_size = self.crop_size // self.scale
        
        # Validate LR crop is within bounds
        if lr_top + lr_crop_size > lr_h or lr_left + lr_crop_size > lr_w:
            # Resize to ensure valid crop
            lr = cv2.resize(lr, (expected_lr_w, expected_lr_h), interpolation=cv2.INTER_CUBIC)
        
        lr_crop = lr[lr_top:lr_top + lr_crop_size, lr_left:lr_left + lr_crop_size]
        
        # Final validation
        if hr_crop.shape[0] != self.crop_size or hr_crop.shape[1] != self.crop_size:
            hr_crop = cv2.resize(hr_crop, (self.crop_size, self.crop_size), interpolation=cv2.INTER_CUBIC)
        if lr_crop.shape[0] != lr_crop_size or lr_crop.shape[1] != lr_crop_size:
            lr_crop = cv2.resize(lr_crop, (lr_crop_size, lr_crop_size), interpolation=cv2.INTER_CUBIC)
        
        return hr_crop, lr_crop
    
    def _augment(self, hr: np.ndarray, lr: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Random augmentation: flip and rotate"""
        # Horizontal flip
        if random.random() < 0.5:
            hr = np.fliplr(hr).copy()
            lr = np.fliplr(lr).copy()
        
        # Vertical flip
        if random.random() < 0.5:
            hr = np.flipud(hr).copy()
            lr = np.flipud(lr).copy()
        
        # Rotation (0, 90, 180, 270)
        rot = random.choice([0, 1, 2, 3])
        if rot > 0:
            hr = np.rot90(hr, rot).copy()
            lr = np.rot90(lr, rot).copy()
        
        return hr, lr
    
    def __len__(self) -> int:
        return len(self.hr_images)
    
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """
        Returns:
            Dict with 'lr' [C, H, W], 'hr' [C, H, W] tensors, normalized to [0, 1]
            If gpu_degradation=True, 'lr' will be None and must be generated on GPU.
        """
        # Load HR
        hr_path = self.hr_images[idx]
        if self.preload and hr_path in self.cached_hr:
            hr = self.cached_hr[hr_path].copy()
        else:
            hr = self._load_image(hr_path)
        
        # Load or generate LR
        if self.gpu_degradation:
            # Skip CPU degradation - will be done on GPU in training loop
            # Just crop HR, LR will be generated from cropped HR on GPU
            hr = self._center_crop_if_needed(hr, self.crop_size)
            lr = None
        else:
            # Standard CPU degradation
            lr_path = self.lr_images[idx]
            if lr_path is not None and lr_path.exists():
                lr = self._load_image(lr_path)
            else:
                # Use quality-aware degradation if enabled
                if self.use_quality_analyzer:
                    lr = self._apply_degradation_with_quality(hr, hr_path)
                else:
                    lr = self._apply_degradation(hr)
            
            # Random crop (paired)
            hr, lr = self._random_crop(hr, lr)
        
        # Augmentation (only HR if gpu_degradation)
        if self.augment:
            if lr is not None:
                hr, lr = self._augment(hr, lr)
            else:
                hr = self._augment_single(hr)
        
        # Convert to tensor [C, H, W], float32, [0, 1]
        hr = torch.from_numpy(hr.transpose(2, 0, 1)).float() / 255.0
        if lr is not None:
            lr = torch.from_numpy(lr.transpose(2, 0, 1)).float() / 255.0
        
        return {
            'lr': lr,  # None if gpu_degradation=True
            'hr': hr,
            'name': hr_path.stem,
        }
    
    def _center_crop_if_needed(self, img: np.ndarray, crop_size: int) -> np.ndarray:
        """Center crop image if larger than crop_size."""
        h, w = img.shape[:2]
        if h > crop_size or w > crop_size:
            # Random crop position (for training variety)
            top = np.random.randint(0, max(1, h - crop_size + 1))
            left = np.random.randint(0, max(1, w - crop_size + 1))
            img = img[top:top + crop_size, left:left + crop_size]
        return img
    
    def _augment_single(self, img: np.ndarray) -> np.ndarray:
        """Apply augmentation to single image."""
        # Horizontal flip
        if np.random.random() < 0.5:
            img = np.fliplr(img).copy()
        
        # Vertical flip
        if np.random.random() < 0.5:
            img = np.flipud(img).copy()
        
        # Rotation (0, 90, 180, 270)
        rot = np.random.choice([0, 1, 2, 3])
        if rot > 0:
            img = np.rot90(img, rot).copy()
        
        return img


class DatasetFactory:
    """Factory for creating datasets from config"""
    
    @staticmethod
    def create(config: Dict) -> BaseDataset:
        """Create dataset from config dict"""
        # Extract degradation config and check for mode
        # Use `or {}` to handle case where degradation is explicitly None
        degradation = config.get('degradation') or {}
        
        # Check if quality analyzer should be enabled
        use_quality_analyzer = (
            degradation.get('mode') in ['auto', 'smart'] or
            config.get('use_quality_analyzer', False)
        )
        
        return BaseDataset(
            hr_dir=config['hr_dir'],
            lr_dir=config.get('lr_dir'),
            scale=config.get('scale', 4),
            crop_size=config.get('crop_size', 128),
            augment=config.get('augment', True),
            degradation=degradation,
            preload=config.get('preload', False),
            max_images=config.get('max_images'),
            gpu_degradation=config.get('gpu_degradation', False),
            # Auto crop_size parameters
            crop_size_mode=config.get('crop_size_mode', 'manual'),
            auto_crop_max=config.get('auto_crop_max', 960),
            auto_crop_min=config.get('auto_crop_min', 64),
            # Smart degradation parameters
            use_quality_analyzer=use_quality_analyzer,
            quality_analyzer=config.get('quality_analyzer'),
        )
    
    @staticmethod
    def create_multi_dataset(configs: List[Dict], weights: Optional[List[float]] = None,
                              weight_mode: str = 'fixed'):
        """
        Create weighted combination of multiple datasets.
        Returns a MultiDataset that samples from each dataset according to weights.
        
        Args:
            configs: List of dataset configurations
            weights: Optional list of weights (ignored if weight_mode='size_proportional')
            weight_mode: 'fixed' for user weights, 'size_proportional' for auto-calculated
        """
        datasets = [DatasetFactory.create(cfg) for cfg in configs]
        return MultiDataset(datasets, weights, weight_mode=weight_mode)


class MultiDataset(Dataset):
    """Weighted combination of multiple datasets
    
    Supports two weight calculation modes:
    - 'fixed': Use provided weights (default behavior)
    - 'size_proportional': Calculate weights based on dataset sizes
    
    Automatically standardizes crop_size across all datasets to ensure
    consistent tensor shapes for batching.
    """
    
    def __init__(self, datasets: List[Dataset], weights: Optional[List[float]] = None, 
                 weight_mode: str = 'fixed'):
        self.datasets = datasets
        self.weight_mode = weight_mode
        
        # Standardize crop_size across all datasets
        # This is necessary because PyTorch DataLoader requires consistent tensor shapes
        self._standardize_crop_sizes()
        
        if weight_mode == 'size_proportional':
            # Calculate weights proportional to dataset sizes
            dataset_sizes = []
            for ds in datasets:
                try:
                    dataset_sizes.append(len(ds))
                except (TypeError, AttributeError):
                    # Fallback to equal weights if length unknown
                    dataset_sizes.append(1.0)
            
            total_size = sum(dataset_sizes)
            if total_size > 0:
                self.weights = [size / total_size for size in dataset_sizes]
                print(f"[MultiDataset] Size-proportional weights: {self.weights}")
            else:
                self.weights = [1.0 / len(datasets)] * len(datasets)
        else:
            # Use provided or equal weights
            self.weights = weights or [1.0] * len(datasets)
        
        # Normalize weights
        total = sum(self.weights)
        self.weights = [w / total for w in self.weights]
        
        # Compute cumulative weights for sampling
        self.cum_weights = [sum(self.weights[:i+1]) for i in range(len(self.weights))]
    
    def _standardize_crop_sizes(self):
        """
        Standardize crop_size across all datasets to ensure consistent tensor shapes.
        Uses the minimum crop_size from all datasets.
        """
        if not self.datasets:
            return
        
        # Collect crop_sizes from all datasets
        crop_sizes = []
        for ds in self.datasets:
            if hasattr(ds, 'crop_size'):
                crop_sizes.append(ds.crop_size)
        
        if not crop_sizes:
            return
        
        # Find minimum crop_size
        min_crop_size = min(crop_sizes)
        
        # Check if standardization is needed
        unique_sizes = set(crop_sizes)
        if len(unique_sizes) > 1:
            print(f"[MultiDataset] Standardizing crop_sizes: {crop_sizes} -> {min_crop_size}")
            
            # Adjust all datasets to use the minimum crop_size
            for ds in self.datasets:
                if hasattr(ds, 'crop_size') and ds.crop_size != min_crop_size:
                    ds.crop_size = min_crop_size
    
    def __len__(self) -> int:
        # Approximate length
        return max(len(d) for d in self.datasets) * len(self.datasets)
    
    def __getitem__(self, idx: int):
        # Select dataset based on weights
        r = random.random()
        dataset_idx = 0
        for i, cw in enumerate(self.cum_weights):
            if r <= cw:
                dataset_idx = i
                break
        
        # Get random sample from selected dataset
        dataset = self.datasets[dataset_idx]
        sample_idx = random.randint(0, len(dataset) - 1)
        return dataset[sample_idx]
