# SPAN-F Integration Guide

This guide explains how to use **SPAN-F** (XiaomiMM) - the NTIRE 2025 2nd Place winner for Efficient Super-Resolution - for transfer learning and fine-tuning on your anime dataset.

## What is SPAN-F?

**SPAN-F** is an optimized variant of the Swift Parameter-free Attention Network (SPAN) developed by the XiaomiMM team:

- **Architecture**: 32 channels, 10 blocks (vs 26 channels, 12 blocks for SPAN-Tiny)
- **Speed**: Optimized for faster inference
- **Quality**: NTIRE 2025 2nd Place winner
- **Parameters**: ~300K (efficient)

## Download Pre-trained Weights

### Method 1: Google Drive (Official)

1. Visit: https://drive.google.com/file/d/1iYUA2TzKuxI0vzmA-UXr_nB43XgPOXUg/view?usp=sharing
2. Download the checkpoint file
3. Place it in: `pretrained/SPANF_x4.pth`

### Method 2: Using gdown (Command Line)

```bash
pip install gdown
gdown 1iYUA2TzKuxI0vzmA-UXr_nB43XgPOXUg -O pretrained/SPANF_x4.pth
```

### Method 3: Using the Download Script

```bash
python scripts/download_spanf.py
```

This will show you detailed instructions for downloading.

## Fine-tuning SPAN-F on Your Anime Data

### Step 1: Verify Download

Check that the weights are compatible:

```bash
python scripts/download_spanf.py --verify pretrained/SPANF_x4.pth
```

### Step 2: Start Fine-tuning

Use the provided config file:

```bash
python scripts/train.py --config configs/finetune_spanf.yaml
```

Or with custom data paths:

```bash
python scripts/train.py --config configs/finetune_spanf.yaml \
    --data.datasets.0.hr_dir path/to/your/anime/images \
    --data.datasets.1.hr_dir path/to/your/video/frames
```

## Configuration Details

### Model Configuration (configs/finetune_spanf.yaml)

```yaml
model:
  type: spanf          # Use SPAN-F variant
  scale: 4
  channels: 32         # SPAN-F uses 32 channels
  num_blocks: 10       # SPAN-F uses 10 blocks
  use_lora: true
  lora_rank: 4
```

### Training Configuration

```yaml
training:
  pretrained_checkpoint: pretrained/SPANF_x4.pth  # Path to downloaded weights
  lr: 1e-5              # Very low LR for fine-tuning
  batch_size: 16
  
  freeze_strategy:
    enabled: true
    freeze_layers:
      - type: blocks
        count: 5        # Freeze first 5 blocks (out of 10)
```

## Architecture Comparison

| Feature | SPAN-Tiny | SPAN-F |
|---------|-----------|--------|
| Channels | 26 | 32 |
| Blocks | 12 | 10 |
| Parameters | ~250K | ~300K |
| NTIRE 2025 Rank | Reference | 2nd Place |
| Speed | Fast | Very Fast |
| Use Case | Baseline | Production |

## Using SPAN-F for Inference

### Load and Run

```python
from src.inference.engine import InferenceEngine

# Load SPAN-F from checkpoint
engine = InferenceEngine.from_checkpoint(
    checkpoint_path='pretrained/SPANF_x4.pth',
    model_type='span',
    device='cuda',
    use_ema=True
)

# Run inference
result = engine.run('input_image.png')
engine.save_result(result, 'output_image.png')
```

### Manual Model Loading

```python
from src.models.span import SPANF
import torch

# Create SPAN-F model
model = SPANF(scale=4)

# Load pretrained weights
checkpoint = torch.load('pretrained/SPANF_x4.pth', map_location='cpu')
if 'state_dict' in checkpoint:
    state_dict = checkpoint['state_dict']
else:
    state_dict = checkpoint

model.load_state_dict(state_dict, strict=False)
model = model.cuda()
model.eval()
```

## Converting Official Checkpoints

If the official SPAN-F checkpoint has different key names:

```python
from src.utils.checkpoint_loader import convert_spanf_checkpoint

convert_spanf_checkpoint(
    input_path='downloaded_spanf.pth',
    output_path='pretrained/SPANF_x4.pth',
    verify=True
)
```

## Troubleshooting

### Checkpoint Not Loading

If you get key mismatch errors:

1. Use `strict=False` when loading:
   ```python
   model.load_state_dict(state_dict, strict=False)
   ```

2. Convert the checkpoint:
   ```bash
   python -c "from src.utils.checkpoint_loader import convert_spanf_checkpoint; convert_spanf_checkpoint('input.pth', 'output.pth')"
   ```

### Out of Memory

Reduce batch size in the config:
```bash
python scripts/train.py --config configs/finetune_spanf.yaml --batch-size 8
```

### Slow Training

- Use gradient accumulation: `gradient_accumulation_steps: 2`
- Enable mixed precision: `mixed_precision: true`
- Reduce crop size: `crop_size: 96`

## Expected Results

After fine-tuning SPAN-F on anime data:

- **PSNR**: 35-37 dB on anime validation set
- **Inference Speed**: ~10-15ms per 256x256 image on RTX 3060
- **Quality**: Sharp lines, good color consistency, anime-optimized

## References

- **SPAN Paper**: https://arxiv.org/abs/2311.12770
- **SPAN GitHub**: https://github.com/hongyuanyu/SPAN
- **NTIRE 2025 Report**: https://arxiv.org/abs/2504.10686

## Support

For issues with SPAN-F:
1. Check the original SPAN repository: https://github.com/hongyuanyu/SPAN
2. Verify your checkpoint format using the verify script
3. Use the convert function if keys don't match
