"""
Checkpoint loading utilities for transfer learning and fine-tuning.
Handles loading pretrained weights from various checkpoint formats.
"""

import torch
from pathlib import Path
from typing import Dict, Optional, Union
import warnings


def load_pretrained_weights(
    model: torch.nn.Module,
    checkpoint_path: Union[str, Path],
    strict: bool = False,
    device: str = 'cpu',
    verbose: bool = True
) -> bool:
    """
    Load pretrained weights into a model.
    
    Handles various checkpoint formats:
    - Raw state_dict: {key: tensor, ...}
    - Nested state_dict: {'state_dict': {...}, ...}
    - Model checkpoint: {'model_state_dict': {...}, 'epoch': ..., ...}
    - EMA checkpoint: {'ema_model_state_dict': {...}, ...}
    
    Args:
        model: Model to load weights into
        checkpoint_path: Path to checkpoint file
        strict: If False, allows partial loading (missing/extra keys)
        device: Device to load checkpoint on
        verbose: Print loading information
        
    Returns:
        True if successful, False otherwise
    """
    checkpoint_path = Path(checkpoint_path)
    
    if not checkpoint_path.exists():
        warnings.warn(f"Checkpoint not found: {checkpoint_path}")
        return False
    
    try:
        # Load checkpoint
        try:
            checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=True)
        except Exception:
            # Fallback for older checkpoints
            checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
        
        # Extract state dict
        state_dict = None
        ema_state_dict = None
        
        if 'ema_model_state_dict' in checkpoint:
            ema_state_dict = checkpoint['ema_model_state_dict']
            if verbose:
                print(f"  Found EMA weights in checkpoint")
        
        if 'state_dict' in checkpoint:
            state_dict = checkpoint['state_dict']
        elif 'model_state_dict' in checkpoint:
            state_dict = checkpoint['model_state_dict']
        elif 'params' in checkpoint:
            state_dict = checkpoint['params']
        elif isinstance(checkpoint, dict) and all(isinstance(v, torch.Tensor) for v in checkpoint.values()):
            # Raw state dict
            state_dict = checkpoint
        else:
            warnings.warn(f"Unknown checkpoint format. Keys: {list(checkpoint.keys())}")
            return False
        
        # Try loading EMA weights first (better quality), fallback to regular
        loaded_ema = False
        if ema_state_dict is not None:
            try:
                missing, unexpected = model.load_state_dict(ema_state_dict, strict=strict)
                if len(missing) == 0 or not strict:
                    state_dict = ema_state_dict
                    loaded_ema = True
                    if verbose:
                        print(f"  Loaded EMA weights (better quality)")
            except RuntimeError:
                pass  # Fall back to regular weights
        
        if not loaded_ema:
            # Clean up state dict keys (remove 'module.' prefix if present)
            state_dict = _clean_state_dict_keys(state_dict)
            
            # Load weights
            missing, unexpected = model.load_state_dict(state_dict, strict=strict)
            
            if verbose:
                if missing:
                    print(f"  Missing keys: {len(missing)}")
                    if len(missing) <= 5:
                        for k in missing:
                            print(f"    - {k}")
                if unexpected:
                    print(f"  Unexpected keys: {len(unexpected)}")
                    if len(unexpected) <= 5:
                        for k in unexpected:
                            print(f"    - {k}")
        
        if verbose:
            total_params = sum(p.numel() for p in model.parameters())
            loaded_params = sum(state_dict[k].numel() for k in state_dict.keys() if k in dict(model.named_parameters()))
            print(f"  Loaded {loaded_params:,} / {total_params:,} parameters ({loaded_params/total_params*100:.1f}%)")
            
            if 'epoch' in checkpoint:
                print(f"  From epoch: {checkpoint['epoch']}")
        
        return True
        
    except Exception as e:
        warnings.warn(f"Failed to load checkpoint: {e}")
        return False


def _clean_state_dict_keys(state_dict: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
    """
    Clean up state dict keys by removing common prefixes.
    
    Handles:
    - 'module.' prefix (from DataParallel/DistributedDataParallel)
    - 'model.' prefix
    - '_orig_mod.' prefix (from torch.compile)
    """
    cleaned = {}
    for key, value in state_dict.items():
        # Remove common prefixes
        new_key = key
        for prefix in ['module.', 'model.', '_orig_mod.']:
            if new_key.startswith(prefix):
                new_key = new_key[len(prefix):]
        cleaned[new_key] = value
    return cleaned


def get_checkpoint_info(checkpoint_path: Union[str, Path]) -> Optional[Dict]:
    """
    Get information about a checkpoint without loading it fully.
    
    Args:
        checkpoint_path: Path to checkpoint
        
    Returns:
        Dictionary with checkpoint info or None if invalid
    """
    checkpoint_path = Path(checkpoint_path)
    
    if not checkpoint_path.exists():
        return None
    
    try:
        checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
        
        info = {
            'path': str(checkpoint_path),
            'size_mb': checkpoint_path.stat().st_size / (1024 * 1024),
        }
        
        # Check for various keys
        if 'epoch' in checkpoint:
            info['epoch'] = checkpoint['epoch']
        if 'best_loss' in checkpoint:
            info['best_loss'] = checkpoint['best_loss']
        if 'metrics' in checkpoint:
            info['metrics'] = checkpoint['metrics']
        
        # Detect format
        if 'ema_model_state_dict' in checkpoint:
            info['has_ema'] = True
        if 'state_dict' in checkpoint:
            info['format'] = 'state_dict'
            info['num_params'] = len(checkpoint['state_dict'])
        elif 'model_state_dict' in checkpoint:
            info['format'] = 'model_state_dict'
            info['num_params'] = len(checkpoint['model_state_dict'])
        else:
            info['format'] = 'raw'
            info['num_params'] = len(checkpoint)
        
        return info
        
    except Exception as e:
        return {'error': str(e)}


def convert_spanf_checkpoint(
    input_path: Union[str, Path],
    output_path: Union[str, Path],
    verify: bool = True
) -> bool:
    """
    Convert SPAN-F checkpoint from official format to this codebase's format.
    
    The official SPAN-F checkpoint may have different key naming.
    This function remaps keys if necessary.
    
    Args:
        input_path: Path to original checkpoint
        output_path: Path to save converted checkpoint
        verify: Verify the conversion by loading
        
    Returns:
        True if successful
    """
    input_path = Path(input_path)
    output_path = Path(output_path)
    
    if not input_path.exists():
        print(f"Error: Input file not found: {input_path}")
        return False
    
    try:
        checkpoint = torch.load(input_path, map_location='cpu', weights_only=False)
        
        # Extract state dict
        if 'state_dict' in checkpoint:
            state_dict = checkpoint['state_dict']
        elif 'model_state_dict' in checkpoint:
            state_dict = checkpoint['model_state_dict']
        elif 'params' in checkpoint:
            state_dict = checkpoint['params']
        else:
            state_dict = checkpoint
        
        # Clean keys
        state_dict = _clean_state_dict_keys(state_dict)
        
        # Check for BasicSR-style keys and remap if needed
        remapped = {}
        for key, value in state_dict.items():
            new_key = key
            
            # BasicSR often uses 'body.X' for blocks, we use 'blocks.X'
            if key.startswith('body.'):
                parts = key.split('.')
                if len(parts) >= 2 and parts[1].isdigit():
                    block_num = parts[1]
                    rest = '.'.join(parts[2:])
                    new_key = f'blocks.{block_num}.{rest}'
            
            remapped[new_key] = value
        
        # Create new checkpoint
        new_checkpoint = {
            'state_dict': remapped,
            'converted_from': str(input_path),
            'converted': True,
        }
        
        # Preserve other metadata if present
        for key in ['epoch', 'best_loss', 'metrics']:
            if key in checkpoint:
                new_checkpoint[key] = checkpoint[key]
        
        # Save
        output_path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(new_checkpoint, output_path)
        
        print(f"Converted checkpoint saved to: {output_path}")
        print(f"  Original keys: {len(state_dict)}")
        print(f"  Remapped keys: {len(remapped)}")
        
        if verify:
            # Try loading
            from models.span import SPANF
            model = SPANF(scale=4)
            try:
                model.load_state_dict(remapped, strict=True)
                print("  Verification: OK - All keys loaded successfully")
            except RuntimeError as e:
                print(f"  Verification warning: {e}")
                print("  Some keys may not match - training will still work with partial loading")
        
        return True
        
    except Exception as e:
        print(f"Error converting checkpoint: {e}")
        import traceback
        traceback.print_exc()
        return False
