"""
Automated multi-stage training orchestrator.
Handles Stage 1 -> Stage 2 transitions automatically.
"""
import torch
from typing import Dict, Optional, Callable
from pathlib import Path

from training.model_a_trainer import ModelATrainer
from training.stage_controller import StageTransitionController
from training.stage_state import StageStateManager
from training.callbacks import StageMonitorCallback


class AutoStageTrainer:
    """
    Automated multi-stage training trainer.
    
    Orchestrates the full pipeline:
    - Stage 1: Train Knowledge Aggregation until convergence
    - Auto-transition to Stage 2 with best checkpoint
    - Stage 2: Train SPAN Student until convergence
    
    Args:
        config: Training configuration
        state_manager: Optional StageStateManager (created if None)
        stage_controller: Optional StageTransitionController (created if None)
    """
    
    def __init__(
        self,
        config: Dict,
        state_manager: Optional[StageStateManager] = None,
        stage_controller: Optional[StageTransitionController] = None,
    ):
        self.config = config
        
        # Initialize state management
        checkpoint_dir = config.get('paths', {}).get('checkpoint_dir', 'checkpoints')
        self.state_manager = state_manager or StageStateManager(
            state_dir=checkpoint_dir,
            training_id="auto_stage"
        )
        
        # Initialize stage controller
        self.stage_controller = stage_controller or StageTransitionController(
            config=config,
            state_manager=self.state_manager,
        )
        
        # Create underlying trainer
        self.trainer = ModelATrainer(config)
        
        # Track stage progress
        self.current_stage = 1
        self.stage_completed = False
    
    def train(self, train_loader, val_loader=None) -> Dict[str, any]:
        """
        Execute full automated multi-stage training.
        
        Args:
            train_loader: Training data loader
            val_loader: Validation data loader (optional)
            
        Returns:
            Dictionary with training results and stage info
        """
        results = {
            'stage1_completed': False,
            'stage1_best_checkpoint': None,
            'stage2_completed': False,
            'stage2_best_checkpoint': None,
            'stages_advanced': False,
        }
        
        # Check if starting from Stage 2 (resumed training)
        if self.stage_controller.state.stage2_started:
            print("\n*** Resuming from Stage 2 ***\n")
            self.current_stage = 2
        
        # Stage 1: Knowledge Aggregation
        if self.current_stage == 1 and not self.stage_controller.state.stage1_completed:
            print("\n" + "="*60)
            print("Stage 1: Training Knowledge Aggregation (Auto-Stage Mode)")
            print("="*60)
            
            stage1_result = self._run_stage1(train_loader, val_loader)
            results['stage1_completed'] = stage1_result['completed']
            results['stage1_best_checkpoint'] = stage1_result['best_checkpoint']
            results['stage1_best_metric'] = stage1_result['best_metric']
            
            if stage1_result['completed'] and self.stage_controller.state.stage2_enabled:
                # Execute transition to Stage 2
                transition_success = self.stage_controller.execute_transition(
                    from_stage=1,
                    to_stage=2,
                    checkpoint_path=stage1_result['best_checkpoint'],
                    metrics={'val_loss': stage1_result['best_metric']}
                )
                
                if transition_success:
                    results['stages_advanced'] = True
                    self.current_stage = 2
        
        # Stage 2: Student Distillation
        if self.current_stage == 2 and self.stage_controller.state.stage2_enabled:
            print("\n" + "="*60)
            print("Stage 2: Training SPAN Student (Auto-Stage Mode)")
            print("="*60)
            
            stage2_result = self._run_stage2(train_loader, val_loader)
            results['stage2_completed'] = stage2_result['completed']
            results['stage2_best_checkpoint'] = stage2_result['best_checkpoint']
            results['stage2_best_metric'] = stage2_result['best_metric']
        
        # Final summary
        print("\n" + "="*60)
        print("Auto-Stage Training Complete")
        print("="*60)
        self.stage_controller.print_status()
        
        return results
    
    def _run_stage1(self, train_loader, val_loader) -> Dict:
        """Run Stage 1 training."""
        result = {
            'completed': False,
            'best_checkpoint': None,
            'best_metric': float('inf'),
        }
        
        # Get stage 1 config
        stage1_cfg = self.config.get('training', {}).get('stage1', {})
        max_epochs = stage1_cfg.get('epochs', 100)
        
        # Setup trainer for Stage 1
        self.trainer.stage = 1
        self.trainer.stage1_epochs = max_epochs
        self.trainer.model = self.trainer._create_model(self.config)
        self.trainer.model = self.trainer.model.to(self.trainer.device)
        self.trainer.best_loss = float('inf')
        
        # Create optimizer and scheduler
        optimizer = self.trainer._create_optimizer()
        self.trainer.set_scheduler(self.trainer._create_scheduler(optimizer, stage='stage1'))
        optimizer._step_count = 0
        
        # Setup stage monitoring
        stage_monitor = StageMonitorCallback(
            stage_controller=self.stage_controller,
            current_stage=1,
        )
        
        # Add to callbacks if not already present
        if self.trainer.callbacks is None:
            from training.callbacks import CallbackList
            self.trainer.callbacks = CallbackList([stage_monitor])
        else:
            self.trainer.callbacks.add(stage_monitor)
        
        # Training loop with auto-stop
        for epoch in range(max_epochs):
            self.trainer.current_epoch = epoch
            
            # Train
            train_metrics = self.trainer.train_stage1_epoch(train_loader, optimizer)
            print(f"Epoch {epoch}: loss={train_metrics['loss']:.4f}")
            
            # Validate
            val_metrics = {}
            if val_loader is not None and epoch % self.trainer.val_interval == 0:
                val_metrics = self.trainer.validate(val_loader)
                print(f"Validation: loss={val_metrics['loss']:.4f}, PSNR={val_metrics['psnr']:.2f}")
                
                if val_metrics['loss'] < self.trainer.best_loss:
                    self.trainer.best_loss = val_metrics['loss']
                    self.trainer.save_checkpoint(epoch, optimizer, is_best=True)
                    result['best_checkpoint'] = str(self.trainer.checkpoint_dir / 'best.pth')
                    result['best_metric'] = val_metrics['loss']
            
            # Save checkpoint
            if epoch % self.trainer.save_interval == 0:
                self.trainer.save_checkpoint(epoch, optimizer)
            
            # Step scheduler
            if self.trainer.scheduler is not None:
                self.trainer.scheduler.step()
            
            # Callback: epoch end
            combined_metrics = {**train_metrics, **val_metrics}
            self.trainer.callbacks.on_epoch_end(epoch, combined_metrics)
            
            # Check if stage complete
            if stage_monitor.is_stage_complete():
                print(f"\nStage 1 converged at epoch {epoch}")
                result['completed'] = True
                break
            
            # Check early stopping if enabled
            if self.trainer.callbacks.should_stop():
                print(f"\nEarly stopping triggered at epoch {epoch}")
                result['completed'] = True
                break
        
        # If not converged, mark as complete anyway (reached max epochs)
        if not result['completed']:
            result['completed'] = True
            result['best_checkpoint'] = str(self.trainer.checkpoint_dir / 'best.pth')
        
        return result
    
    def _run_stage2(self, train_loader, val_loader) -> Dict:
        """Run Stage 2 training."""
        result = {
            'completed': False,
            'best_checkpoint': None,
            'best_metric': float('inf'),
        }
        
        # Get stage 2 config
        stage2_cfg = self.config.get('training', {}).get('stage2', {})
        max_epochs = stage2_cfg.get('epochs', 200)
        
        # Recreate model as SPAN student
        self.trainer.stage = 2
        self.trainer.model = self.trainer._create_model(self.config)
        self.trainer.model = self.trainer.model.to(self.trainer.device)
        self.trainer.best_loss = float('inf')
        
        # Reinitialize EMA model
        if self.trainer.use_ema:
            self.trainer.ema_model = self.trainer._create_ema_model()
        
        # Create optimizer and scheduler
        optimizer = self.trainer._create_optimizer()
        self.trainer.set_scheduler(self.trainer._create_scheduler(optimizer, stage='stage2'))
        optimizer._step_count = 0
        
        # Re-initialize callbacks for Stage 2
        self.trainer._setup_callbacks()
        
        # Setup stage monitoring
        stage_monitor = StageMonitorCallback(
            stage_controller=self.stage_controller,
            current_stage=2,
        )
        if self.trainer.callbacks is None:
            from training.callbacks import CallbackList
            self.trainer.callbacks = CallbackList([stage_monitor])
        else:
            self.trainer.callbacks.add(stage_monitor)
        
        # Training loop
        for epoch in range(max_epochs):
            self.trainer.current_epoch = epoch
            
            # Train
            train_metrics = self.trainer.train_stage2_epoch(train_loader, optimizer)
            print(f"Epoch {epoch}: loss={train_metrics['loss']:.4f}")
            
            # Validate
            val_metrics = {}
            if val_loader is not None and epoch % self.trainer.val_interval == 0:
                val_metrics = self.trainer.validate(val_loader)
                print(f"Validation: loss={val_metrics['loss']:.4f}, PSNR={val_metrics['psnr']:.2f}")
                
                if val_metrics['loss'] < self.trainer.best_loss:
                    self.trainer.best_loss = val_metrics['loss']
                    self.trainer.save_checkpoint(epoch, optimizer, is_best=True)
                    result['best_checkpoint'] = str(self.trainer.checkpoint_dir / 'best.pth')
                    result['best_metric'] = val_metrics['loss']
            
            # Save checkpoint
            if epoch % self.trainer.save_interval == 0:
                self.trainer.save_checkpoint(epoch, optimizer)
            
            # Step scheduler
            if self.trainer.scheduler is not None:
                self.trainer.scheduler.step()
            
            # Callback: epoch end
            combined_metrics = {**train_metrics, **val_metrics}
            self.trainer.callbacks.on_epoch_end(epoch, combined_metrics)
            
            # Check early stopping if enabled
            if self.trainer.callbacks.should_stop():
                print(f"\nEarly stopping triggered at epoch {epoch}")
                result['completed'] = True
                break
        
        # If not converged, mark as complete anyway
        if not result['completed']:
            result['completed'] = True
            result['best_checkpoint'] = str(self.trainer.checkpoint_dir / 'best.pth')
        
        return result
    
    def reset(self):
        """Reset the trainer for fresh training."""
        self.stage_controller.reset()
        self.current_stage = 1
        self.stage_completed = False
        print("AutoStageTrainer reset. Ready for fresh training.")
    
    def get_status(self) -> Dict:
        """Get current training status."""
        return {
            'current_stage': self.current_stage,
            'stage_controller_status': self.stage_controller.get_stage_status(),
        }
