"""
Unit tests for new preprocessing components.
Tests: storage_estimator, dataset_sampler, preprocessing_manager, and integration.
"""
import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))


class TestStorageEstimator:
    """Tests for storage_estimator.py"""
    
    def test_estimate_single_image_size(self):
        from data.storage_estimator import estimate_single_image_size
        
        # Test PNG estimation
        result = estimate_single_image_size(1920, 1080, format='png')
        assert result['hr_mb'] > 0
        assert result['lr_mb'] > 0
        assert result['total_mb'] > 0
        assert result['lr_mb'] < result['hr_mb']  # LR should be smaller
        
        # Test JPEG estimation
        result_jpg = estimate_single_image_size(1920, 1080, format='jpeg')
        assert result_jpg['total_mb'] < result['total_mb']  # JPEG should be smaller than PNG
    
    def test_estimate_dataset_storage(self):
        from data.storage_estimator import estimate_dataset_storage
        
        # Test with actual data directory
        result = estimate_dataset_storage(
            hr_dir='data/anime_video_frames',
            crop_size=128,
            scale=4,
            format='png',
            sample_ratio=0.1  # Use 10% for quick test
        )
        
        if 'error' not in result:
            assert result['total_images'] > 0
            assert result['images_to_use'] > 0
            assert result['total_storage_gb'] > 0
            assert 'per_dataset_breakdown' in result
    
    def test_check_against_available_space(self):
        from data.storage_estimator import check_against_available_space
        
        # Test insufficient space
        estimate = {
            'total_storage_gb': 15.0,
            'worst_case_total_gb': 20.0
        }
        result = check_against_available_space(estimate, 10.0)
        assert result['sufficient_space'] == False
        assert result['space_shortage_gb'] > 0
        
        # Test sufficient space
        result2 = check_against_available_space(estimate, 25.0)
        assert result2['sufficient_space'] == True


class TestDatasetSampler:
    """Tests for dataset_sampler.py"""
    
    def test_create_sampler(self):
        from data.dataset_sampler import DatasetSampler
        
        configs = [
            {'name': 'test1', 'hr_dir': 'data/anime_video_frames', 
             'sample_ratio': 0.1, 'weight': 1.0, 'is_validation': False, 'enabled': True},
        ]
        
        sampler = DatasetSampler(configs, max_images_total=100)
        assert len(sampler) > 0
        assert len(sampler) <= 100
    
    def test_global_cap(self):
        from data.dataset_sampler import DatasetSampler
        
        configs = [
            {'name': 'test1', 'hr_dir': 'data/anime_video_frames', 
             'sample_ratio': 1.0, 'weight': 1.0, 'is_validation': False, 'enabled': True},
        ]
        
        sampler = DatasetSampler(configs, max_images_total=50)
        assert len(sampler) <= 50
    
    def test_sampled_indices(self):
        from data.dataset_sampler import DatasetSampler
        
        configs = [
            {'name': 'test1', 'hr_dir': 'data/anime_video_frames', 
             'sample_ratio': 0.5, 'weight': 1.0, 'is_validation': False, 'enabled': True},
        ]
        
        sampler = DatasetSampler(configs, max_images_total=200)
        indices = sampler.get_sampled_indices(0)
        assert len(indices) <= 200
        assert len(indices) == sampler.total_images


class TestPreprocessingManager:
    """Tests for preprocessing_manager.py"""
    
    def test_create_manager(self):
        from data.preprocessing_manager import PreprocessingManager
        
        config = {
            'mode': 'hybrid',
            'scale': 4,
            'gpu_degradation': {
                'enabled': True,
                'modules': {'blur': True, 'quantization': True}
            },
            'line_enhancement': {'enabled': False}
        }
        
        manager = PreprocessingManager(config)
        assert manager is not None
        assert manager.mode == 'hybrid'
        assert manager.device is not None
    
    def test_get_info(self):
        from data.preprocessing_manager import PreprocessingManager
        
        config = {
            'mode': 'gpu_degradation',
            'gpu_degradation': {
                'enabled': True,
                'modules': {'blur': True, 'directional_blur': True}
            }
        }
        
        manager = PreprocessingManager(config)
        info = manager.get_info()
        
        assert 'mode' in info
        assert 'gpu_modules' in info
        assert 'blur' in info['gpu_modules']
    
    def test_modes(self):
        from data.preprocessing_manager import PreprocessingManager
        
        valid_modes = ['on_the_fly', 'precomputed', 'gpu_degradation', 'hybrid', 'quality_adaptive']
        
        for mode in valid_modes:
            config = {'mode': mode, 'scale': 4}
            manager = PreprocessingManager(config)
            assert manager.mode == mode


class TestConfigIntegration:
    """Tests for config parsing and integration"""
    
    def test_base_yaml_parse(self):
        import yaml
        with open('configs/base.yaml', 'r') as f:
            config = yaml.safe_load(f)
        
        assert 'data' in config
        assert 'preprocessing' in config['data']
        preprocessing = config['data']['preprocessing']
        assert preprocessing['mode'] == 'hybrid'
        assert 'storage' in preprocessing
        assert 'dataset_sampling' in preprocessing
    
    def test_v4_yaml_parse(self):
        import yaml
        with open('configs/finetune_neosr_span_v4.yaml', 'r') as f:
            config = yaml.safe_load(f)
        
        assert 'data' in config
        assert 'preprocessing' in config['data']
    
    def test_v5_yaml_parse(self):
        import yaml
        with open('configs/finetune_neosr_span_v5.yaml', 'r') as f:
            config = yaml.safe_load(f)
        
        assert 'data' in config
        assert 'preprocessing' in config['data']


class TestBaseDatasetIntegration:
    """Tests for BaseDataset integration with new parameters"""
    
    def test_sample_ratio_param(self):
        from data.base import BaseDataset
        
        # This will fail if directory doesn't exist, but tests param acceptance
        # We just verify the parameter exists in the constructor
        import inspect
        sig = inspect.signature(BaseDataset.__init__)
        params = list(sig.parameters.keys())
        assert 'sample_ratio' in params
        assert 'preprocessing_manager' in params
    
    def test_factory_accepts_preprocessing_config(self):
        from data.base import DatasetFactory
        import inspect
        sig = inspect.signature(DatasetFactory.create)
        params = list(sig.parameters.keys())
        assert 'preprocessing_config' in params


class TestDataloaderIntegration:
    """Tests for DataLoaderFactory integration"""
    
    def test_dataloader_uses_preprocessing(self):
        from data.dataloader import DataLoaderFactory
        import yaml
        
        with open('configs/finetune_neosr_span_v4.yaml', 'r') as f:
            config = yaml.safe_load(f)
        
        # Should not raise - validates config parsing
        assert 'data' in config
        preprocessing_cfg = config['data'].get('preprocessing')
        assert preprocessing_cfg is not None


if __name__ == '__main__':
    pytest.main([__file__, '-v', '--tb=short'])