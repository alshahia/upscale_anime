"""
Regression tests for Phase 4 Low Priority Fixes.

Tests:
1. PyTorch AMP imports work for both 1.x and 2.0+
2. Config paths are documented
"""
import sys
from pathlib import Path

# Add project root to Python path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import pytest


def test_pytorch_amp_imports():
    """Test that PyTorch AMP imports work correctly."""
    import torch
    
    # Test GradScaler import (from base_trainer pattern)
    try:
        from torch.amp import GradScaler  # PyTorch 2.0+
    except ImportError:
        from torch.cuda.amp import GradScaler  # PyTorch 1.x
    
    # Should be able to create a GradScaler
    scaler = GradScaler()
    assert scaler is not None
    
    # Test autocast import (from model_a_trainer pattern)
    try:
        from torch.amp import autocast  # PyTorch 2.0+
    except ImportError:
        from torch.cuda.amp import autocast as _autocast  # PyTorch 1.x
        
        # Define wrapper for compatibility
        def autocast(device=None, enabled=True):
            return _autocast(enabled=enabled)
    
    print("✓ PyTorch AMP imports work correctly")


def test_config_has_path_documentation():
    """Test that config file has documentation for data paths."""
    config_path = project_root / 'configs' / 'auto_stage_pipeline.yaml'
    assert config_path.exists(), f"Config file not found: {config_path}"
    
    content = config_path.read_text()
    
    # Check for documentation comment
    assert 'NOTE: Update these paths' in content, "Config should have path documentation"
    assert 'overridden via CLI' in content, "Config should mention CLI override"
    
    print("✓ Config file has path documentation")


def test_unused_imports_removed():
    """Test that unused imports have been cleaned up."""
    # Check base_trainer.py doesn't have unused autocast
    base_trainer_path = project_root / 'src' / 'training' / 'base_trainer.py'
    content = base_trainer_path.read_text()
    
    # Should NOT have 'autocast' import (since it's not used in the file)
    lines = content.split('\n')
    import_lines = [l for l in lines if 'import' in l and 'autocast' in l]
    
    # The file should only import GradScaler, not autocast
    for line in import_lines:
        assert 'GradScaler' in line or 'autocast' not in line, \
            "base_trainer.py should not import unused autocast"
    
    print("✓ Unused imports have been cleaned up")


def test_model_a_trainer_has_autocast_compatibility():
    """Test that model_a_trainer has the autocast compatibility wrapper."""
    model_a_path = project_root / 'src' / 'training' / 'model_a_trainer.py'
    content = model_a_path.read_text()
    
    # Should have the compatibility wrapper for PyTorch 1.x
    assert 'def autocast(device=None, enabled=True):' in content or \
           'from torch.amp import autocast' in content, \
        "model_a_trainer should have autocast compatibility"
    
    print("✓ model_a_trainer has autocast compatibility")


if __name__ == '__main__':
    print("Running Phase 4 Low Priority Fixes regression tests...\n")
    
    test_pytorch_amp_imports()
    test_config_has_path_documentation()
    test_unused_imports_removed()
    test_model_a_trainer_has_autocast_compatibility()
    
    print("\n✅ All Phase 4 tests passed!")
