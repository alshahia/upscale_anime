# AGENTS.md — upscale_anime

## Project

PyTorch anime super-resolution with progressive ensemble distillation and neosr SPAN finetuning. Model paths:
- **Model A**: SPAN-Tiny + MTKD/FAKD distillation from EDSR/RCAN/SwinIR teachers
- **Model B**: Mamba-PAN with 4-direction scanning (requires `mamba-ssm`)
- **Finetune**: neosr SPAN with multi-loss (perceptual, GAN, frequency, FDL, wavelet-guided) training via `src/training/neosr_finetuner.py`

## Setup

```bash
uv pip install torch torchvision --index-url https://download.pytorch.org/whl/cu126
uv pip install -r requirements.txt
```
# alwayes serach for local venv ( if exists) use it for all commands ( if not exist use the global python)

No `pyproject.toml`, `setup.py`, or lockfile. Dependencies managed via `requirements.txt` only.

## Key Commands

```bash
# Always use --config (required arg)
python scripts/train.py --config configs/model_a_ntire.yaml
python scripts/train.py --config configs/model_a_ntire.yaml --dry-run   # validate config only
python scripts/train.py --config configs/auto_stage_pipeline.yaml       # full automated pipeline

# Optimized finetune (v4 - APISR-style degradation, twin perceptual, FDL, wavelet-guided)
python scripts/train.py --config configs/finetune_neosr_span_v4.yaml
python scripts/train.py --config configs/finetune_neosr_span_v4.yaml --dry-run

# Download teacher models (auto-downloaded by default in Stage 1)
python scripts/download_models.py --model all --scale 4

# Run tests
pytest tests/

# Lint / format (from requirements.txt)
black .
flake8 .

# Inference
python scripts/inference.py --model-type neosr_span --checkpoint checkpoints/finetune_best.pth --input data/test/ --output results/
python scripts/inference.py --model-type neosr_span --checkpoint checkpoints/finetune_best.pth --input lr.jpg --output sr.png --gt ground_truth.png --metrics

# Quality evaluation
python scripts/evaluate_quality.py --input results/ --output quality_report.csv

# Dataset analysis
python scripts/analyze_dataset.py --dir data/anime_hr
```

Note: `.agentrc` references `ruff`, `bandit`, `mypy` — these are **not** in requirements.txt. Use `black` + `flake8`.

## Architecture

```
src/                  # All library code (bare imports: from models..., from training...)
  models/             # span/, mamba_pan/, teachers/ (edsr, rcan, swinir)
  training/           # orchestrator, trainers, callbacks, stage_controller
  distillation/       # mtkd/ (aggregation), fakd/ (affinity loss)
  losses/             # pixel, wavelet, perceptual, anime-specific
  data/               # dataloader, augmentation, video_extraction, anime_degradation
  inference/          # engine
  utils/              # config, metrics, pretrained_models, nan_handler
scripts/              # All entry points (CLI scripts)
configs/              # YAML configs; base.yaml is the root
tests/                # pytest tests (no conftest.py, no pytest.ini)
```

**Import convention**: scripts add `src` to `sys.path` then use bare imports (`from models.span...`). Never use `src.` prefix. Match existing files.

**Test coverage**: ~25-30% of `src/` modules have tests. No `conftest.py`, no `pytest.ini`. Many modules (orchestrator, ensemble_trainer, losses, utils) are untested. Don't assume test coverage is comprehensive.

## Training Modes

`model_a` | `model_b` | `both_parallel` | `both_sequential` | `ensemble` | `full` | `auto_stage` | `finetune`

## Critical Gotchas

- **Quality Metrics**: Use LPIPS (not just PSNR/SSIM) to evaluate perceptual quality. LPIPS correlates with human judgment; lower is better. PSNR >25dB and SSIM >0.85 are good targets. See `src/utils/metrics.py` for available metrics.
- **No-Reference Evaluation**: For real-world images without GT, use `scripts/evaluate_quality.py` with NIQE/MANIQA/CLIPIQA. CLIPIQA performs best for anime content (used by APISR/CVPR 2024).
- **Two-Phase Training**: The finetune mode uses two-phase training by default (Phase 1: epochs 1-30 for structure, Phase 2: epochs 31-50 for texture). This balances pixel accuracy with perceptual quality.
- **Perceptual Loss Types**: DISTS for texture preservation, Dual (VGG+ResNet) for structural features. Use `type: dists` or `type: dual` in config. Both are supported.
- **Line Art Edge Detection**: Multi-scale edge detection (`edge_method: multi_scale`) captures both thick character outlines and thin detail lines. Use this for anime content.
- **Progressive Crop Training**: During finetune, you can use progressive crop to gradually increase patch size for better feature learning at different scales. Set `progressive_crop.enabled: true` with stages defining crop sizes and epoch counts. Example: epochs 1-15 use crop=128, 16-50 use crop=256, 51-80 use crop=512. Crop changes are logged but dataloader restart is needed for full effect. See `configs/finetune_neosr_span_v3.yaml` for config schema.
- **Stage 1 NaN losses**: Knowledge Aggregation can produce NaN/Inf with small batches or multiple teachers. Use `use_simple_aggregation: true` or single-teacher mode. See `src/utils/nan_handler.py`.
- **Discriminator in GAN training**: Discriminator and DISTS must run in FP32 under mixed precision. See "Mixed precision FP32 override" below.
- **Defensive config access**: Use `config.get('key') or {}` not `config.get('key', {})` — values can be explicitly `None`.
- **PyTorch 2.x API**: Use `torch.amp.autocast('cuda', ...)` and `GradScaler('cuda')`, not the deprecated `torch.cuda.amp` variants.
- **Mixed precision FP32 override**: DISTS perceptual loss, frequency loss, and discriminator MUST run in FP32 under autocast. Use `torch.amp.autocast('cuda', enabled=False)` with `.float()` inputs. FP16 causes silent NaN in these operations. See `src/training/neosr_finetuner.py`.
- **Windows terminal**: Avoid unicode in print statements (`✓`, `✗`, emojis). Use ASCII (`[OK]`, `[ERROR]`). cp1252 encoding breaks on chars above U+00FF.
- **Platform-dependent features**: Before enabling features like `torch.compile()`, `triton`, or hardware-accelerated codecs, verify availability on the current platform. Windows lacks Triton support; use feature flags with safe defaults (`false` on Windows, `true` on Linux).
- **Python indentation**: When inserting code into existing Python files, read at least 10 lines of surrounding context to match the exact indentation level (tabs vs spaces, depth). After editing, verify with `python -m py_compile <file>`.
- **Optional deps**: `tensorboard`, `mamba-ssm`, `matplotlib` use try/except import with availability flags. Gracefully degrade.
- **Device placement**: Loss modules with pre-trained extractors (VGG, DISTS) need `.to(device)` — buffers (mean/std) must follow.
- **VRAM target**: 8GB (RTX 4000 Mobile). Keep batch sizes modest.
- **Checkpoint compatibility**: Multiple `checkpoint_compatible_model*.py` variants exist in `src/models/span/`. When loading fails, analyze checkpoint keys first, then pick the matching loader. Don't guess — inspect with `torch.load(path).keys()`.
- **Pre-flight before training**: Before running long training jobs, verify: config is valid YAML (`--dry-run`), data paths exist, no unicode in print statements, GPU is available (`torch.cuda.is_available()`).
- **Multi-dataset tensor shapes**: When combining datasets, crop sizes must match for batching. Check `src/data/dataloader.py` for standardization logic.
- **torch.load security**: Always use `weights_only=True` with fallback to `weights_only=False`. Pattern: `try: torch.load(path, weights_only=True) except Exception: torch.load(path, weights_only=False)`. See `src/training/base_trainer.py:328-344` for canonical implementation.
- **Config schema consistency**: All configs must match `base.yaml` schema. Duplicate top-level keys (e.g., `training:` appearing 3x) silently merge unpredictably. Non-standard keys (`optimizer.type`, `datasets.train`) won't work with the standard config loader. Validate with `--dry-run`.
- **Silent exception handling**: Avoid bare `except Exception:` without logging. The codebase has 18+ unlogged exception handlers. Always log the exception: `except Exception as e: logger.warning(f"...: {e}")`.
- **np.random reproducibility**: `np.random` calls in `nn.Module.forward()` (e.g., `src/data/anime_degradation.py`) break `torch.manual_seed()` reproducibility. Use `torch.rand()` or `torch.randint()` with a `torch.Generator` instead.
- **New dependencies**: LPIPS and pyiqa are required for quality evaluation. Install with: `pip install lpips pyiqa`
- **V4 enhancements**: `configs/finetune_neosr_span_v4.yaml` includes APISR-style degradation (WebP/AVIF/H.264 compression, shuffled resize), twin perceptual loss (VGG19+ResNet50), FDL loss (DINOv2), wavelet-guided GAN, and XDoG line enhancement. Target scores: NIQE <5.0, MANIQA >0.5, CLIPIQA >0.6.

## V4 Quality Improvements

The v4 config (`finetune_neosr_span_v4.yaml`) incorporates techniques from APISR (CVPR 2024) and state-of-the-art SR research:

### Degradation Model
- **Two-stage compression**: Stage 1 (JPEG+WebP before resize), Stage 2 (AVIF+H.264 after resize)
- **Shuffled resize**: Random order of degradation operations (blur, noise, resize, compression)
- **Degrade-before-crop**: Apply degradation on full image before cropping (APISR approach)

### Loss Functions
- **Twin Perceptual Loss**: VGG19 (ImageNet) + ResNet50 with balanced scaling (`L_per = L_ResNet + delta * L_VGG`)
- **FDL Loss**: Frequency Distribution Loss with DINOv2 features and sliced Wasserstein distance
- **Wavelet-Guided Loss**: Haar wavelet decomposition for GAN stability (HH subband weighted 2x)
- **XDoG Line Enhancement**: Pseudo-GT with sharpened hand-drawn lines

### GAN Training
- **Higher adversarial weight**: 0.001 (Phase 2), max 0.005 (vs 0.0001/0.0005 in v3)
- **Higher discriminator LR**: 0.0001 (vs 0.000005 in v3)
- **Longer training**: 150 epochs (vs 80 in v3), Phase 1 extended to 50 epochs

## Checkpoint Management

The training system includes automatic checkpoint management to prevent overwriting previous runs.

### Run Naming

| Method | Description |
|--------|-------------|
| **Auto (Hybrid)** | `run_{timestamp}_{model_name}_{suffix}` e.g., `run_20240115_143052_neosr_span_progCrop` |
| **Custom** | Use `--run-name "my_exp"` in CLI or `output.run_name` in config |

### Duplicate Handling

When a run name already exists, the system can:
- **`auto_increment`**: Automatically append `_001`, `_002`, etc.
- **`ask`**: Prompt user to choose (CLI mode)

Config: `output.duplicate_handling: auto_increment` or `ask`

### CLI Options

```bash
# Auto-generated name
python scripts/train.py --config configs/finetune_neosr_span_v3.yaml

# Custom name
python scripts/train.py --config configs/finetune_neosr_span_v3.yaml --run-name "exp_progCrop_v1"

# Override via config
# In config: output.run_name: "my_exp"
```

### Tracker CSV

All runs are logged to `checkpoints/run_tracker.csv`:

| Field | Description |
|-------|-------------|
| run_id | Unique ID (run_001, run_002, ...) |
| run_name | Directory name |
| config_file | Config used |
| timestamp | Start time |
| status | started/completed/interrupted |
| best_loss | Best validation loss |
| final_epoch | Epoch reached |
| checkpoint_dir | Full path |

### Config Value Restoration on Resume

When resuming from a checkpoint, training-critical config values that affect training behavior (not just weights) should be restored from the checkpoint:

- `phase1_epochs` / `phase2_epochs` for two-phase training
- `adversarial_start_epoch` for GAN training
- `progressive_crop` stages and current crop size

This ensures resumed training continues with the correct phase/loss schedule, even if the current config has different values than when training started.

**Example**: If checkpoint was saved at epoch 37 with `phase1_epochs=40`, resuming should use `phase1_epochs=40` (from checkpoint), not the current config's value.

### Testing Checkpoint Save/Load

When adding new training features that affect loss computation or phase determination, add tests that:

1. Save a checkpoint with modified config values
2. Load the checkpoint in a fresh instance with different config values
3. Verify the loaded values match the checkpoint, not the current config

**Example**: `test_phase_determination_with_restored_phase1_epochs()` in `tests/test_two_phase_training.py`

## Quality Evaluation

For super-resolution quality assessment, use these metrics:

| Metric | Type | Target | Direction |
|--------|------|--------|-----------|
| PSNR | Full-ref | >25 dB | higher is better |
| SSIM | Full-ref | >0.85 | higher is better |
| LPIPS | Full-ref | <0.25 | lower is better |
| NIQE | No-ref | <5.0 | lower is better |
| MANIQA | No-ref | >0.7 | higher is better |
| CLIPIQA | No-ref | >0.7 | higher is better |

Command-line evaluation:
```bash
# With ground truth
python scripts/inference.py --gt ground_truth.png --metrics

# Batch no-reference evaluation
python scripts/evaluate_quality.py --input results/ --metrics niqe maniqa clipiqa --output report.csv
```

## Data Flow

1. Place HR images in `data/` or videos in `data/anime_vid/`
2. Video frames extracted via `scripts/process_videos.py` (pre or on-demand mode)
3. RealESRGAN-style degradation generates LR pairs on-the-fly (configurable presets: light/medium/heavy/anime)
4. Teacher models auto-download to `pretrained/` if missing

## GPU Utilization Optimization

Training was bottlenecked by loss computation (51% of batch time), not data loading. Profiling revealed:

| Config | Total (ms) | Loss (ms) | Forward (ms) | Backward (ms) | Speedup |
|--------|------------|-----------|--------------|---------------|---------|
| v4 (Twin VGG+ResNet50) | 505 | 259 | 76 | 162 | baseline |
| v4_speed (VGG + no checkpointing) | 339 | 139 | 106 | 86 | **1.49x** |

### Key Optimizations Applied
- **Perceptual loss**: Twin VGG19+ResNet50 (202ms) -> VGG single layer (89ms) = 56% faster
- **FDL compute_every**: 2 -> 4 (saves 50% of DINOv2 forward passes)
- **Gradient checkpointing**: disabled (trades VRAM for speed; we have headroom at 2.9GB/8.6GB)
- **VGGPerceptualLoss bug fix**: Added `.features` accessor (was crashing silently)

### Profiling Tools
- `scripts/profile_gpu.py` — measures data load, forward, loss, backward, optimizer step times
- `scripts/profile_loss_breakdown.py` — measures time per individual loss component

### Loss Component Timing (v4 original)
| Component | Time (ms) | % of Loss | Fix Applied |
|-----------|-----------|-----------|-------------|
| Perceptual (Twin) | 202 | 49.6% | Switched to VGG single layer |
| FDL (DINOv2) | 112 | 27.6% | compute_every: 4 |
| Discriminator | 77 | 18.8% | Required for GAN |
| Frequency | 10 | 2.6% | Keep (fast) |
| Others | <5 | <2% | Keep |

## Pre-Completion Checklist

Before marking a multi-step task as complete:
- [ ] All new modules/classes are imported and wired into existing factories/pipelines
- [ ] All new config options have been traced: config → code path → execution
- [ ] Platform-dependent features have been verified for the current OS (Windows/Linux/macOS)
- [ ] `py_compile` or equivalent syntax check passes on all modified Python files
- [ ] `--dry-run` or equivalent validation passes for config changes
- [ ] No dead code: every new file is imported by at least one existing module

## Git-ignored

`data/`, `checkpoints/`, `logs/`, `results/`, `pretrained/`, `*.pth`, `*.pt`, `*.ckpt`, `.venv/`

## Dead Code Patterns

The project accumulates dead code through iterative development. Before adding new variants:
- **Checkpoint models**: `src/models/span/` had 7 `checkpoint_compatible_model*.py` files (6 were dead). Keep only the one actually imported.
- **Checkpoint loaders**: `src/utils/` had 3 loaders (2 never imported). Consolidate before adding new ones.
- **Config files**: `configs/` accumulates debug/working variants with non-standard schemas. Delete broken configs, don't fix them.
- **Summary .md files**: Implementation summaries in root become stale quickly. Prefer updating AGENTS.md.

Rule of thumb: if a file isn't imported by `src/` or referenced by a config, it's likely dead.

## Existing Agent Instructions

- `.windsurf/rules/base.md` — extensive style/debugging/convention rules (v1.8)
- `.windsurf/.agentrc` — references quality gate (partially outdated)
- `.windsurf/workflows/` — many workflow prompt files (mostly generic, not repo-specific)
