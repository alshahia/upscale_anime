"""
Adversarial Loss for GAN-based Super-Resolution
Includes discriminator and various GAN loss formulations
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional, Dict


class SRDiscriminator(nn.Module):
    """
    Discriminator for Super-Resolution GAN.
    PatchGAN-style architecture for local realism.
    """
    
    def __init__(
        self,
        in_channels: int = 3,
        num_features: int = 64,
        num_layers: int = 3,
    ):
        super().__init__()
        
        layers = []
        
        # First layer
        layers.append(nn.Conv2d(in_channels, num_features, kernel_size=4, stride=2, padding=1))
        layers.append(nn.LeakyReLU(0.2, inplace=True))
        
        # Middle layers
        nf = num_features
        for i in range(num_layers):
            nf_prev = nf
            nf = min(nf * 2, 512)
            stride = 1 if i == num_layers - 1 else 2
            layers.append(nn.Conv2d(nf_prev, nf, kernel_size=4, stride=stride, padding=1))
            layers.append(nn.BatchNorm2d(nf))
            layers.append(nn.LeakyReLU(0.2, inplace=True))
        
        # Final layer - output single value per patch
        layers.append(nn.Conv2d(nf, 1, kernel_size=4, stride=1, padding=1))
        
        self.model = nn.Sequential(*layers)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            x: Input image [B, 3, H, W]
        
        Returns:
            Discriminator output [B, 1, H', W']
        """
        return self.model(x)


class VanillaGANLoss(nn.Module):
    """Standard GAN loss (binary cross entropy)"""
    
    def __init__(self):
        super().__init__()
        self.loss_fn = nn.BCEWithLogitsLoss()
    
    def forward(
        self,
        disc_output: torch.Tensor,
        is_real: bool,
    ) -> torch.Tensor:
        """
        Compute GAN loss.
        
        Args:
            disc_output: Discriminator output
            is_real: True for real samples, False for fake
        
        Returns:
            GAN loss
        """
        target = torch.ones_like(disc_output) if is_real else torch.zeros_like(disc_output)
        return self.loss_fn(disc_output, target)


class RelativisticGANLoss(nn.Module):
    """
    Relativistic GAN loss.
    Discriminator compares real vs fake relatively.
    """
    
    def __init__(self):
        super().__init__()
    
    def forward(
        self,
        real_output: torch.Tensor,
        fake_output: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute relativistic GAN loss.
        
        Args:
            real_output: Discriminator output for real samples
            fake_output: Discriminator output for fake samples
        
        Returns:
            Relativistic GAN loss
        """
        # For real samples: real should be larger than fake
        loss_real = F.softplus(fake_output - real_output).mean()
        
        # For fake samples: fake should be larger than real
        loss_fake = F.softplus(real_output - fake_output).mean()
        
        return loss_real + loss_fake


class HingeGANLoss(nn.Module):
    """Hinge GAN loss (used in SAGAN, BigGAN)"""
    
    def __init__(self):
        super().__init__()
    
    def forward(
        self,
        disc_output: torch.Tensor,
        is_real: bool,
    ) -> torch.Tensor:
        """
        Compute hinge GAN loss.
        
        Args:
            disc_output: Discriminator output
            is_real: True for real, False for fake
        
        Returns:
            Hinge loss
        """
        if is_real:
            return torch.mean(F.relu(1.0 - disc_output))
        else:
            return torch.mean(F.relu(1.0 + disc_output))


class AdversarialLoss(nn.Module):
    """
    Adversarial loss wrapper for generator training.
    """
    
    def __init__(
        self,
        loss_type: str = "vanilla",  # vanilla, relativistic, hinge
    ):
        super().__init__()
        self.loss_type = loss_type
        
        if loss_type == "vanilla":
            self.loss_fn = VanillaGANLoss()
        elif loss_type == "relativistic":
            self.loss_fn = RelativisticGANLoss()
        elif loss_type == "hinge":
            self.loss_fn = HingeGANLoss()
        else:
            raise ValueError(f"Unknown GAN loss type: {loss_type}")
    
    def forward(
        self,
        disc_output_fake: torch.Tensor,
        disc_output_real: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Compute adversarial loss for generator.
        
        Args:
            disc_output_fake: Discriminator output for generated (fake) samples
            disc_output_real: Discriminator output for real samples (for relativistic)
        
        Returns:
            Adversarial loss
        """
        if self.loss_type == "relativistic" and disc_output_real is not None:
            return self.loss_fn(disc_output_real, disc_output_fake)
        else:
            # For vanilla and hinge, generator wants to fool discriminator
            return self.loss_fn(disc_output_fake, is_real=True)


class GANTrainer:
    """
    Helper class for training GAN components.
    Not a loss function, but manages discriminator training.
    """
    
    def __init__(
        self,
        discriminator: nn.Module,
        loss_type: str = "vanilla",
        lr: float = 1e-4,
    ):
        self.discriminator = discriminator
        self.adversarial_loss = AdversarialLoss(loss_type)
        self.optimizer = torch.optim.Adam(discriminator.parameters(), lr=lr, betas=(0.9, 0.99))
    
    def train_step(
        self,
        real_images: torch.Tensor,
        fake_images: torch.Tensor,
    ) -> Dict[str, float]:
        """
        Train discriminator one step.
        
        Args:
            real_images: Real HR images
            fake_images: Generated SR images
        
        Returns:
            Dict with discriminator loss
        """
        self.optimizer.zero_grad()
        
        # Discriminator on real
        disc_real = self.discriminator(real_images)
        
        # Discriminator on fake
        disc_fake = self.discriminator(fake_images.detach())
        
        # Compute loss
        if isinstance(self.adversarial_loss.loss_fn, RelativisticGANLoss):
            d_loss = self.adversarial_loss.loss_fn(disc_real, disc_fake)
        else:
            loss_real = self.adversarial_loss.loss_fn(disc_real, is_real=True)
            loss_fake = self.adversarial_loss.loss_fn(disc_fake, is_real=False)
            d_loss = (loss_real + loss_fake) / 2
        
        d_loss.backward()
        self.optimizer.step()
        
        return {
            'd_loss': d_loss.item(),
            'disc_real': disc_real.mean().item(),
            'disc_fake': disc_fake.mean().item(),
        }


# Convenience function
def create_adversarial_loss(loss_type: str = "vanilla") -> AdversarialLoss:
    """Create adversarial loss"""
    return AdversarialLoss(loss_type)


def create_discriminator(
    in_channels: int = 3,
    num_features: int = 64,
) -> SRDiscriminator:
    """Create discriminator"""
    return SRDiscriminator(in_channels, num_features)
