"""
XDoG-based line enhancement for anime super-resolution.
Creates pseudo-ground-truth with enhanced hand-drawn lines.

Reference: APISR (CVPR 2024) - Pseudo-GT with enhanced hand-drawn lines
Uses XDoG (Extended Difference of Gaussians) for edge extraction,
outlier filtering, and passive dilation to sharpen anime lines.
"""
import numpy as np
import cv2
from typing import Tuple


class LineEnhancer:
    """
    Enhances hand-drawn lines in anime images for pseudo-GT preparation.

    Pipeline:
    1. XDoG edge extraction (Difference of Gaussians)
    2. Outlier filtering (remove noise pixels)
    3. Passive dilation (thicken lines slightly)
    4. Merge with original: pseudo_gt = original + alpha * line_overlay

    Reference: APISR (CVPR 2024), Section 3.3
    https://arxiv.org/abs/2403.01598
    """

    def __init__(
        self,
        sigma1: float = 1.0,
        sigma2: float = 16.0,
        alpha: float = 0.1,
        gamma: float = 0.5,
        phi: float = 100.0,
        dilation_size: int = 2,
        outlier_threshold: int = 5,
    ):
        self.sigma1 = sigma1
        self.sigma2 = sigma2
        self.alpha = alpha
        self.gamma = gamma
        self.phi = phi
        self.dilation_size = dilation_size
        self.outlier_threshold = outlier_threshold

    def _xdog(self, gray: np.ndarray) -> np.ndarray:
        """Extended Difference of Gaussians for edge extraction."""
        g1 = cv2.GaussianBlur(gray, (0, 0), self.sigma1)
        g2 = cv2.GaussianBlur(gray, (0, 0), self.sigma2)

        dog = g1 - self.gamma * g2
        dog = dog / 255.0

        edges = np.where(dog > 0, 1.0, 1.0 + np.tanh(self.phi * dog))
        edges = np.clip(edges, 0, 1)
        return (edges * 255).astype(np.uint8)

    def _filter_outliers(self, edges: np.ndarray) -> np.ndarray:
        """Remove isolated noise pixels (outliers)."""
        kernel = np.ones((3, 3), np.uint8)
        opened = cv2.morphologyEx(edges, cv2.MORPH_OPEN, kernel, iterations=1)

        contours, _ = cv2.findContours(opened, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        filtered = np.zeros_like(edges)
        for contour in contours:
            if cv2.contourArea(contour) >= self.outlier_threshold:
                cv2.drawContours(filtered, [contour], -1, 255, -1)

        return filtered

    def _passive_dilation(self, edges: np.ndarray) -> np.ndarray:
        """Slightly thicken lines for better visibility."""
        if self.dilation_size <= 0:
            return edges

        kernel = np.ones((self.dilation_size, self.dilation_size), np.uint8)
        dilated = cv2.dilate(edges, kernel, iterations=1)

        lines_only = cv2.subtract(dilated, edges)
        lines_only = cv2.erode(lines_only, kernel, iterations=1)

        result = cv2.add(edges, lines_only)
        return result

    def __call__(self, img: np.ndarray) -> np.ndarray:
        """
        Apply line enhancement to create pseudo-GT.

        Args:
            img: Input anime image [H, W, C], RGB, uint8

        Returns:
            Enhanced image with sharpened lines
        """
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

        edges = self._xdog(gray)
        edges = self._filter_outliers(edges)
        edges = self._passive_dilation(edges)

        edges_3ch = cv2.cvtColor(edges, cv2.COLOR_GRAY2RGB)

        line_overlay = (255 - edges_3ch).astype(np.float32) / 255.0
        line_overlay = line_overlay * self.alpha * 255

        enhanced = img.astype(np.float32) + line_overlay
        enhanced = np.clip(enhanced, 0, 255).astype(np.uint8)

        return enhanced
