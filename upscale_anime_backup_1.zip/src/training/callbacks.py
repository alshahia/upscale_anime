"""
Training Callbacks
EMA, checkpointing, logging, and learning rate scheduling
"""
import torch
import torch.nn as nn
from pathlib import Path
from typing import Dict, Optional, Any, Callable
import json
import time


class Callback:
    """Base callback class"""
    
    def on_train_begin(self, logs: Dict = None):
        pass
    
    def on_train_end(self, logs: Dict = None):
        pass
    
    def on_epoch_begin(self, epoch: int, logs: Dict = None):
        pass
    
    def on_epoch_end(self, epoch: int, logs: Dict = None):
        pass
    
    def on_batch_begin(self, batch: int, logs: Dict = None):
        pass
    
    def on_batch_end(self, batch: int, logs: Dict = None):
        pass


class EMACallback(Callback):
    """
    Exponential Moving Average callback.
    Maintains EMA version of model parameters.
    """
    
    def __init__(self, model: nn.Module, decay: float = 0.999):
        self.model = model
        self.decay = decay
        self.ema_model = self._create_ema_model(model)
        self.num_updates = 0
    
    def _create_ema_model(self, model: nn.Module) -> nn.Module:
        """Create EMA model copy"""
        import copy
        ema_model = copy.deepcopy(model)
        for param in ema_model.parameters():
            param.requires_grad = False
        return ema_model
    
    def update(self):
        """Update EMA parameters"""
        self.num_updates += 1
        
        # Compute decay rate with warmup
        decay = min(self.decay, (1 + self.num_updates) / (10 + self.num_updates))
        
        with torch.no_grad():
            for ema_param, model_param in zip(self.ema_model.parameters(), self.model.parameters()):
                ema_param.data.mul_(decay).add_(model_param.data, alpha=1 - decay)
    
    def on_batch_end(self, batch: int, logs: Dict = None):
        self.update()
    
    def get_model(self) -> nn.Module:
        """Get EMA model"""
        return self.ema_model
    
    def apply_ema(self):
        """Apply EMA weights to original model (for evaluation)"""
        self.backup = {}
        for name, param in self.model.named_parameters():
            self.backup[name] = param.data.clone()
            param.data.copy_(self.ema_model.state_dict()[name])
    
    def restore_original(self):
        """Restore original model weights"""
        if hasattr(self, 'backup'):
            for name, param in self.model.named_parameters():
                param.data.copy_(self.backup[name])
            self.backup = {}


class CheckpointCallback(Callback):
    """
    Model checkpointing callback.
    Saves checkpoints at intervals and keeps best model.
    """
    
    def __init__(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        checkpoint_dir: str = "checkpoints",
        save_interval: int = 10,
        keep_last_n: int = 5,
        monitor: str = "val_loss",
        mode: str = "min",
    ):
        self.model = model
        self.optimizer = optimizer
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        self.save_interval = save_interval
        self.keep_last_n = keep_last_n
        self.monitor = monitor
        self.mode = mode
        
        self.best_value = float('inf') if mode == "min" else float('-inf')
        self.checkpoints = []
    
    def on_epoch_end(self, epoch: int, logs: Dict = None):
        if logs is None:
            logs = {}
        
        # Save regular checkpoint
        if epoch % self.save_interval == 0:
            self._save_checkpoint(epoch, logs, is_best=False)
        
        # Save best checkpoint
        current_value = logs.get(self.monitor)
        if current_value is not None:
            is_better = (current_value < self.best_value) if self.mode == "min" else (current_value > self.best_value)
            
            if is_better:
                self.best_value = current_value
                self._save_checkpoint(epoch, logs, is_best=True)
    
    def _save_checkpoint(self, epoch: int, logs: Dict, is_best: bool = False):
        """Save checkpoint"""
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'logs': logs,
        }
        
        # Save checkpoint
        if is_best:
            path = self.checkpoint_dir / 'best.pth'
        else:
            path = self.checkpoint_dir / f'epoch_{epoch}.pth'
        
        torch.save(checkpoint, path)
        
        if not is_best:
            self.checkpoints.append(path)
            
            # Cleanup old checkpoints
            if len(self.checkpoints) > self.keep_last_n:
                old_checkpoint = self.checkpoints.pop(0)
                if old_checkpoint.exists():
                    old_checkpoint.unlink()


class TensorBoardCallback(Callback):
    """TensorBoard logging callback"""
    
    def __init__(self, log_dir: str = "logs", enabled: bool = True):
        self.enabled = enabled
        self.writer = None
        
        if enabled:
            try:
                from torch.utils.tensorboard import SummaryWriter
                self.writer = SummaryWriter(log_dir=log_dir)
            except ImportError:
                print("Warning: TensorBoard not available. Install with: pip install tensorboard")
                self.enabled = False
        
        self.global_step = 0
    
    def on_batch_end(self, batch: int, logs: Dict = None):
        if not self.enabled or logs is None:
            return
        
        # Log metrics
        for name, value in logs.items():
            if isinstance(value, (int, float)):
                self.writer.add_scalar(f'train/{name}', value, self.global_step)
        
        self.global_step += 1
    
    def on_epoch_end(self, epoch: int, logs: Dict = None):
        if not self.enabled or logs is None:
            return
        
        # Log epoch metrics
        for name, value in logs.items():
            if isinstance(value, (int, float)):
                self.writer.add_scalar(f'epoch/{name}', value, epoch)
    
    def on_train_end(self, logs: Dict = None):
        if self.enabled and self.writer:
            self.writer.close()


class LRSchedulerCallback(Callback):
    """Learning rate scheduling callback"""
    
    def __init__(self, optimizer: torch.optim.Optimizer, scheduler: Any):
        self.optimizer = optimizer
        self.scheduler = scheduler
    
    def on_epoch_end(self, epoch: int, logs: Dict = None):
        if self.scheduler:
            self.scheduler.step()
            
            # Log learning rate
            lr = self.optimizer.param_groups[0]['lr']
            if logs is not None:
                logs['lr'] = lr


class ProgressCallback(Callback):
    """Progress printing callback"""
    
    def __init__(self, print_interval: int = 1):
        self.print_interval = print_interval
        self.epoch_times = []
    
    def on_epoch_begin(self, epoch: int, logs: Dict = None):
        self.epoch_start_time = time.time()
    
    def on_epoch_end(self, epoch: int, logs: Dict = None):
        epoch_time = time.time() - self.epoch_start_time
        self.epoch_times.append(epoch_time)
        
        if epoch % self.print_interval == 0:
            avg_time = sum(self.epoch_times[-10:]) / min(len(self.epoch_times), 10)
            
            log_str = f"Epoch {epoch}"
            if logs:
                for key, value in logs.items():
                    if isinstance(value, float):
                        log_str += f" - {key}: {value:.4f}"
            
            log_str += f" - time: {epoch_time:.1f}s (avg: {avg_time:.1f}s)"
            print(log_str)


class CallbackList:
    """Manager for multiple callbacks"""
    
    def __init__(self, callbacks: Optional[list] = None):
        self.callbacks = callbacks or []
    
    def add(self, callback: Callback):
        self.callbacks.append(callback)
    
    def on_train_begin(self, logs: Dict = None):
        for callback in self.callbacks:
            callback.on_train_begin(logs)
    
    def on_train_end(self, logs: Dict = None):
        for callback in self.callbacks:
            callback.on_train_end(logs)
    
    def on_epoch_begin(self, epoch: int, logs: Dict = None):
        for callback in self.callbacks:
            callback.on_epoch_begin(epoch, logs)
    
    def on_epoch_end(self, epoch: int, logs: Dict = None):
        for callback in self.callbacks:
            callback.on_epoch_end(epoch, logs)
    
    def on_batch_begin(self, batch: int, logs: Dict = None):
        for callback in self.callbacks:
            callback.on_batch_begin(batch, logs)
    
    def on_batch_end(self, batch: int, logs: Dict = None):
        for callback in self.callbacks:
            callback.on_batch_end(batch, logs)
