"""
Custom learning rate schedulers for training.
Includes warmup + cosine annealing, multi-step with warmup, etc.
"""
import torch
from torch.optim.lr_scheduler import _LRScheduler
import math


class WarmupCosineScheduler(_LRScheduler):
    """
    Cosine annealing scheduler with linear warmup.
    
    Args:
        optimizer: PyTorch optimizer
        warmup_epochs: Number of epochs for linear warmup
        total_epochs: Total number of training epochs
        min_lr: Minimum learning rate after cosine annealing
        last_epoch: Last epoch index (for resuming)
    """
    
    def __init__(
        self,
        optimizer,
        warmup_epochs: int = 10,
        total_epochs: int = 100,
        min_lr: float = 1e-7,
        last_epoch: int = -1,
    ):
        self.warmup_epochs = warmup_epochs
        self.total_epochs = total_epochs
        self.min_lr = float(min_lr)  # Ensure float type
        self.base_lrs = [float(group['lr']) for group in optimizer.param_groups]  # Ensure float type
        
        super().__init__(optimizer, last_epoch)
    
    def get_lr(self):
        """Compute learning rate for current epoch."""
        if self.last_epoch < self.warmup_epochs:
            # Linear warmup
            alpha = self.last_epoch / self.warmup_epochs
            return [float(base_lr) * alpha for base_lr in self.base_lrs]
        else:
            # Cosine annealing
            remaining_epochs = self.total_epochs - self.warmup_epochs
            if remaining_epochs <= 0:
                progress = 1.0  # Already at end of training
            else:
                progress = (self.last_epoch - self.warmup_epochs) / remaining_epochs
            progress = min(1.0, progress)
            
            cosine_decay = 0.5 * (1 + math.cos(math.pi * progress))
            return [self.min_lr + (float(base_lr) - self.min_lr) * cosine_decay 
                    for base_lr in self.base_lrs]


class WarmupMultiStepScheduler(_LRScheduler):
    """
    Multi-step LR scheduler with linear warmup.
    
    Args:
        optimizer: PyTorch optimizer
        warmup_epochs: Number of warmup epochs
        milestones: List of epoch indices to reduce LR
        gamma: LR decay factor at each milestone
        min_lr: Minimum learning rate
    """
    
    def __init__(
        self,
        optimizer,
        warmup_epochs: int = 10,
        milestones: list = None,
        gamma: float = 0.5,
        min_lr: float = 1e-7,
        last_epoch: int = -1,
    ):
        self.warmup_epochs = warmup_epochs
        self.milestones = milestones or [50, 100, 150]
        self.gamma = gamma
        self.min_lr = float(min_lr)  # Ensure float type
        self.base_lrs = [float(group['lr']) for group in optimizer.param_groups]  # Ensure float type
        
        super().__init__(optimizer, last_epoch)
    
    def get_lr(self):
        """Compute learning rate."""
        if self.last_epoch < self.warmup_epochs:
            # Linear warmup
            alpha = self.last_epoch / self.warmup_epochs
            return [float(base_lr) * alpha for base_lr in self.base_lrs]
        else:
            # Multi-step decay
            decay_factor = self.gamma ** sum(1 for m in self.milestones if m <= self.last_epoch)
            return [max(self.min_lr, float(base_lr) * decay_factor) for base_lr in self.base_lrs]


class WarmupConstantScheduler(_LRScheduler):
    """
    Constant LR after warmup (useful for fine-tuning).
    """
    
    def __init__(
        self,
        optimizer,
        warmup_epochs: int = 10,
        last_epoch: int = -1,
    ):
        self.warmup_epochs = warmup_epochs
        self.base_lrs = [float(group['lr']) for group in optimizer.param_groups]  # Ensure float type
        
        super().__init__(optimizer, last_epoch)
    
    def get_lr(self):
        """Compute learning rate."""
        if self.last_epoch < self.warmup_epochs:
            alpha = self.last_epoch / self.warmup_epochs
            return [float(base_lr) * alpha for base_lr in self.base_lrs]
        else:
            return [float(base_lr) for base_lr in self.base_lrs]


def create_scheduler(optimizer, config: dict, stage: str = 'stage1'):
    """
    Factory function to create scheduler based on config.
    
    Args:
        optimizer: PyTorch optimizer
        config: Training configuration dict
        stage: 'stage1' or 'stage2'
        
    Returns:
        Scheduler instance
    """
    stage_cfg = config.get('training', {}).get(stage, {})
    
    scheduler_name = stage_cfg.get('scheduler', 'cosine')
    warmup_epochs = stage_cfg.get('warmup_epochs', 10)
    epochs = stage_cfg.get('epochs', 100)
    min_lr = stage_cfg.get('min_lr', 1e-7)
    
    if scheduler_name == 'cosine':
        scheduler = WarmupCosineScheduler(
            optimizer,
            warmup_epochs=warmup_epochs,
            total_epochs=epochs,
            min_lr=min_lr,
        )
    elif scheduler_name == 'multistep':
        milestones = stage_cfg.get('milestones', [epochs // 3, epochs * 2 // 3])
        gamma = stage_cfg.get('gamma', 0.5)
        scheduler = WarmupMultiStepScheduler(
            optimizer,
            warmup_epochs=warmup_epochs,
            milestones=milestones,
            gamma=gamma,
            min_lr=min_lr,
        )
    elif scheduler_name == 'constant':
        scheduler = WarmupConstantScheduler(
            optimizer,
            warmup_epochs=warmup_epochs,
        )
    else:
        # Fallback to base trainer's scheduler
        return None
    
    return scheduler
