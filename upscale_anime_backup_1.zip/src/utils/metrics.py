"""
Metrics for Super-Resolution evaluation
PSNR, SSIM, LPIPS
"""
import torch
import torch.nn.functional as F
import numpy as np
from typing import Union


def calculate_psnr(img1: torch.Tensor, img2: torch.Tensor, max_val: float = 1.0) -> float:
    """
    Calculate PSNR between two images.
    
    Args:
        img1: First image [B, C, H, W] or [C, H, W]
        img2: Second image [B, C, H, W] or [C, H, W]
        max_val: Maximum pixel value (1.0 for normalized images)
    
    Returns:
        PSNR value in dB
    """
    mse = torch.mean((img1 - img2) ** 2)
    # Use epsilon for numerical stability (avoids inf and handles near-zero MSE)
    psnr = 20 * torch.log10(max_val / torch.sqrt(mse + 1e-10))
    return psnr.item()


def calculate_ssim(
    img1: torch.Tensor,
    img2: torch.Tensor,
    window_size: int = 11,
    max_val: float = 1.0,
) -> float:
    """
    Calculate SSIM between two images.
    Simplified implementation.
    
    Args:
        img1: First image [B, C, H, W]
        img2: Second image [B, C, H, W]
        window_size: Size of sliding window
        max_val: Maximum pixel value
    
    Returns:
        SSIM value (0 to 1)
    """
    # Constants
    C1 = (0.01 * max_val) ** 2
    C2 = (0.03 * max_val) ** 2
    
    # Gaussian kernel
    sigma = 1.5
    gauss = torch.Tensor([
        np.exp(-(x - window_size//2)**2 / (2 * sigma**2))
        for x in range(window_size)
    ])
    gauss = gauss / gauss.sum()
    
    # 2D Gaussian kernel
    window = gauss.unsqueeze(1) * gauss.unsqueeze(0)
    window = window.unsqueeze(0).unsqueeze(0).to(img1.device)
    window = window.repeat(img1.size(1), 1, 1, 1)
    
    # Means
    mu1 = F.conv2d(img1, window, padding=window_size//2, groups=img1.size(1))
    mu2 = F.conv2d(img2, window, padding=window_size//2, groups=img2.size(1))
    
    mu1_sq = mu1 ** 2
    mu2_sq = mu2 ** 2
    mu1_mu2 = mu1 * mu2
    
    # Variances and covariance
    sigma1_sq = F.conv2d(img1 ** 2, window, padding=window_size//2, groups=img1.size(1)) - mu1_sq
    sigma2_sq = F.conv2d(img2 ** 2, window, padding=window_size//2, groups=img2.size(1)) - mu2_sq
    sigma12 = F.conv2d(img1 * img2, window, padding=window_size//2, groups=img1.size(1)) - mu1_mu2
    
    # SSIM
    ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / \
               ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))
    
    return ssim_map.mean().item()


def calculate_batch_metrics(
    preds: torch.Tensor,
    targets: torch.Tensor,
    max_val: float = 1.0,
) -> dict:
    """
    Calculate metrics for a batch.
    
    Args:
        preds: Predictions [B, C, H, W]
        targets: Ground truth [B, C, H, W]
        max_val: Maximum pixel value
    
    Returns:
        Dictionary with PSNR and SSIM
    """
    batch_size = preds.size(0)
    
    psnr_total = 0.0
    ssim_total = 0.0
    
    for i in range(batch_size):
        psnr = calculate_psnr(preds[i], targets[i], max_val)
        ssim = calculate_ssim(preds[i:i+1], targets[i:i+1], max_val=max_val)
        
        psnr_total += psnr
        ssim_total += ssim
    
    return {
        'psnr': psnr_total / batch_size,
        'ssim': ssim_total / batch_size,
    }


class MetricsTracker:
    """Track metrics during training/validation"""
    
    def __init__(self):
        self.metrics = {}
        self.counts = {}
    
    def update(self, metrics_dict: dict):
        """Update metrics"""
        for key, value in metrics_dict.items():
            if key not in self.metrics:
                self.metrics[key] = 0.0
                self.counts[key] = 0
            
            self.metrics[key] += value
            self.counts[key] += 1
    
    def get_average(self) -> dict:
        """Get average metrics"""
        return {
            key: self.metrics[key] / self.counts[key]
            for key in self.metrics.keys()
        }
    
    def reset(self):
        """Reset metrics"""
        self.metrics = {}
        self.counts = {}
