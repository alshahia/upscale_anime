"""
Configuration management system
Hierarchical YAML configs with CLI override support
"""
import yaml
import argparse
from pathlib import Path
from typing import Any, Dict, Optional, Union
from dataclasses import dataclass, field


class Config:
    """
    Hierarchical configuration manager.
    Supports: YAML loading, CLI argument merging, nested access
    """
    
    def __init__(self, config_dict: Optional[Dict] = None):
        self._config = config_dict or {}
    
    @classmethod
    def load(cls, path: Union[str, Path]) -> 'Config':
        """Load config from YAML file"""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        
        with open(path, 'r', encoding='utf-8') as f:
            config_dict = yaml.safe_load(f)
        
        # Handle inheritance (base config)
        if 'base' in config_dict:
            base_path = path.parent / config_dict.pop('base')
            base_config = cls.load(base_path)
            base_config.merge(config_dict)
            return base_config
        
        return cls(config_dict)
    
    def merge(self, other: Union[Dict, 'Config']):
        """Merge another config into this one (recursive)"""
        if isinstance(other, Config):
            other = other._config
        
        def recursive_merge(base: Dict, override: Dict) -> Dict:
            for key, value in override.items():
                if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                    base[key] = recursive_merge(base[key], value)
                else:
                    base[key] = value
            return base
        
        self._config = recursive_merge(self._config, other)
    
    def merge_args(self, args: argparse.Namespace):
        """Merge CLI arguments (dot notation: --model.channels 32)"""
        args_dict = vars(args)
        for key, value in args_dict.items():
            if value is not None:
                self._set_nested(key, value)
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get value with dot notation (e.g., 'model.channels')"""
        keys = key.split('.')
        value = self._config
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        return value
    
    def set(self, key: str, value: Any):
        """Set value with dot notation"""
        self._set_nested(key, value)
    
    def _set_nested(self, key: str, value: Any):
        """Set nested value using dot notation, supports list indices"""
        # Validate key format
        if not key or not isinstance(key, str):
            raise ValueError(f"Config key must be a non-empty string, got: {type(key).__name__}")

        keys = key.split('.')

        # Validate each key segment
        for i, k in enumerate(keys):
            # Check for path traversal sequences
            if k == '..' or k.startswith('..') or '/../' in k or '\\..\\' in k:
                raise ValueError(f"Invalid config key (path traversal detected): {key}")
            # Allow numeric indices for lists and valid identifiers for dicts
            if not (k.isdigit() or k.isidentifier() or k.replace('-', '').isalnum()):
                raise ValueError(f"Invalid config key segment '{k}' in key: {key}")

        config = self._config
        
        for i, k in enumerate(keys[:-1]):
            # Check if next key is numeric (list index)
            next_key = keys[i + 1]
            is_next_numeric = next_key.isdigit()
            
            # If k is numeric string, use as list index
            if k.isdigit():
                idx = int(k)
                # Ensure list is long enough
                while len(config) <= idx:
                    config.append({} if not is_next_numeric else [])
                config = config[idx]
            else:
                # k is a string key
                if k not in config:
                    # Create list or dict based on next key
                    config[k] = [] if is_next_numeric else {}
                config = config[k]
        
        # Set final value
        final_key = keys[-1]
        if final_key.isdigit():
            idx = int(final_key)
            while len(config) <= idx:
                config.append(None)
            config[idx] = value
        else:
            config[final_key] = value
    
    def validate(self, schema: Optional[Dict] = None) -> bool:
        """Validate config against schema (basic checks)"""
        required_keys = [
            'model.name',
            'model.scale',
            'training.batch_size',
            'training.epochs',
            'data.crop_size',
        ]
        
        for key in required_keys:
            if self.get(key) is None:
                raise ValueError(f"Missing required config key: {key}")
        
        return True
    
    def to_dict(self) -> Dict:
        """Export to dictionary"""
        return self._config.copy()
    
    def save(self, path: Union[str, Path]):
        """Save config to YAML file"""
        with open(path, 'w', encoding='utf-8') as f:
            yaml.dump(self._config, f, default_flow_style=False)
    
    def __getitem__(self, key: str) -> Any:
        """Allow dict-like access: config['model.channels']"""
        return self.get(key)
    
    def __setitem__(self, key: str, value: Any):
        """Allow dict-like setting: config['model.channels'] = 32"""
        self.set(key, value)
    
    def __contains__(self, key: str) -> bool:
        """Allow 'in' checks: 'model.channels' in config"""
        return self.get(key) is not None
    
    def __repr__(self) -> str:
        return f"Config({self._config})"
    
    @staticmethod
    def add_argument_parser(parser: argparse.ArgumentParser):
        """Add standard arguments to argparse"""
        parser.add_argument('--config', '-c', type=str, required=True,
                          help='Path to config YAML file')
        parser.add_argument('--mode', '-m', type=str, 
                          choices=['model_a', 'model_b', 'both_parallel', 'both_sequential', 'ensemble', 'full'],
                          help='Training mode')
        parser.add_argument('--resume', '-r', type=str,
                          help='Resume from checkpoint path')
        parser.add_argument('--device', type=str, default='cuda',
                          help='Device to use (cuda/cpu)')
        parser.add_argument('--num-workers', type=int,
                          help='Number of dataloader workers')
        parser.add_argument('--batch-size', type=int,
                          help='Override batch size')
        parser.add_argument('--epochs', type=int,
                          help='Override number of epochs')
        parser.add_argument('--lr', type=float,
                          help='Override learning rate')
        parser.add_argument('--dry-run', action='store_true',
                          help='Validate config and exit')
        parser.add_argument('--tensorboard', action='store_true',
                          help='Enable TensorBoard logging')
