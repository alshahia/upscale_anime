"""
Inference Engine for Super-Resolution
High-level interface for running inference
"""
import torch
import numpy as np
from pathlib import Path
from typing import Union, Optional, List, Dict
import cv2

from models.span import create_span_model, SPANModel
from models.mamba_pan import create_mamba_pan_model, MambaPANModel
from models.ensemble import EnsembleTeacher, TinyStudent


class InferenceEngine:
    """
    High-level inference engine for super-resolution models.
    
    Supports:
    - Single image inference
    - Batch inference
    - Video processing
    - Model switching
    """
    
    def __init__(
        self,
        model: torch.nn.Module,
        device: str = 'cuda',
        use_amp: bool = True,
    ):
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        self.model = model.to(self.device)
        self.model.eval()
        
        self.use_amp = use_amp and self.device.type == 'cuda'
    
    @classmethod
    def from_checkpoint(
        cls,
        checkpoint_path: Union[str, Path],
        model_type: str = 'span',
        device: str = 'cuda',
        config: Optional[Dict] = None,
    ) -> 'InferenceEngine':
        """
        Create inference engine from checkpoint.
        
        Args:
            checkpoint_path: Path to model checkpoint
            model_type: 'span', 'mamba_pan', or 'tiny_student'
            device: Device to load model on
            config: Optional model configuration
        
        Returns:
            InferenceEngine instance
        """
        checkpoint_path = Path(checkpoint_path)
        
        if not checkpoint_path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
        
        # Load checkpoint
        checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=True)
        
        # Determine config
        if config is None:
            if 'config' in checkpoint:
                config = checkpoint['config']
                if hasattr(config, 'to_dict'):
                    config = config.to_dict()
            else:
                config = {}
        
        # Create model
        model_config = config.get('model', {}) if 'model' in config else config
        
        if model_type == 'span':
            model = create_span_model(model_config)
        elif model_type == 'mamba_pan':
            model = create_mamba_pan_model(model_config)
        elif model_type == 'tiny_student':
            from models.ensemble import TinyStudent
            model = TinyStudent(scale=model_config.get('scale', 4))
        else:
            raise ValueError(f"Unknown model type: {model_type}")
        
        # Load weights
        if 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
        elif 'state_dict' in checkpoint:
            model.load_state_dict(checkpoint['state_dict'])
        else:
            model.load_state_dict(checkpoint)
        
        print(f"Loaded {model_type} model from {checkpoint_path}")
        print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
        
        return cls(model, device=device)
    
    @classmethod
    def from_ensemble(
        cls,
        model_a_checkpoint: Union[str, Path],
        model_b_checkpoint: Union[str, Path],
        device: str = 'cuda',
        weights: List[float] = [0.6, 0.4],
    ) -> 'InferenceEngine':
        """
        Create inference engine from ensemble.
        
        Args:
            model_a_checkpoint: Path to Model A checkpoint
            model_b_checkpoint: Path to Model B checkpoint
            device: Device to load models on
            weights: Ensemble weights [w_a, w_b]
        
        Returns:
            InferenceEngine instance
        """
        from models.ensemble import create_ensemble_teacher
        
        ensemble = create_ensemble_teacher(
            str(model_a_checkpoint),
            str(model_b_checkpoint),
            device=device,
            weights=weights,
        )
        
        print(f"Created ensemble teacher with weights: {weights}")
        
        return cls(ensemble, device=device)
    
    def preprocess(self, image: np.ndarray) -> torch.Tensor:
        """
        Preprocess numpy image to tensor.
        
        Args:
            image: Input image [H, W, C] or [H, W], BGR or RGB
        
        Returns:
            Preprocessed tensor [1, C, H, W]
        """
        # Ensure 3 channels
        if len(image.shape) == 2:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        elif image.shape[2] == 4:
            image = cv2.cvtColor(image, cv2.COLOR_BGRA2RGB)
        elif image.shape[2] == 3:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Convert to tensor
        tensor = torch.from_numpy(image).float() / 255.0
        
        # HWC to CHW
        tensor = tensor.permute(2, 0, 1).unsqueeze(0)
        
        return tensor
    
    def postprocess(self, tensor: torch.Tensor) -> np.ndarray:
        """
        Postprocess tensor to numpy image.
        
        Args:
            tensor: Output tensor [1, C, H, W] or [C, H, W]
        
        Returns:
            Numpy image [H, W, C], BGR format
        """
        # Remove batch dimension if present
        if tensor.dim() == 4:
            tensor = tensor.squeeze(0)
        
        # Move to CPU and clamp
        tensor = tensor.detach().cpu().clamp(0, 1)
        
        # CHW to HWC
        image = tensor.permute(1, 2, 0).numpy()
        
        # To uint8
        image = (image * 255).astype(np.uint8)
        
        # RGB to BGR
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        
        return image
    
    def run(
        self,
        lr_image: Union[np.ndarray, torch.Tensor],
        return_tensor: bool = False,
    ) -> Union[np.ndarray, torch.Tensor]:
        """
        Run inference on a single image.
        
        Args:
            lr_image: Low-resolution image (numpy array or tensor)
            return_tensor: If True, return tensor instead of numpy array
        
        Returns:
            Super-resolved image
        """
        # Preprocess if numpy
        if isinstance(lr_image, np.ndarray):
            lr_tensor = self.preprocess(lr_image).to(self.device)
        else:
            lr_tensor = lr_image.to(self.device)
        
        # Add batch dimension if missing
        if lr_tensor.dim() == 3:
            lr_tensor = lr_tensor.unsqueeze(0)
        
        # Inference
        with torch.no_grad():
            with torch.amp.autocast('cuda', enabled=self.use_amp):
                sr_tensor = self.model(lr_tensor)
        
        # Postprocess
        if return_tensor:
            return sr_tensor
        
        return self.postprocess(sr_tensor)
    
    def run_batch(
        self,
        lr_images: List[Union[np.ndarray, torch.Tensor]],
    ) -> List[np.ndarray]:
        """
        Run inference on a batch of images.
        
        Args:
            lr_images: List of low-resolution images
        
        Returns:
            List of super-resolved images
        """
        results = []
        
        for lr_image in lr_images:
            sr_image = self.run(lr_image)
            results.append(sr_image)
        
        return results
    
    def benchmark(
        self,
        input_size: tuple = (3, 128, 128),
        num_runs: int = 100,
        warmup: int = 10,
    ) -> Dict[str, float]:
        """
        Benchmark inference speed.
        
        Args:
            input_size: Input tensor size (C, H, W)
            num_runs: Number of benchmark runs
            warmup: Number of warmup runs
        
        Returns:
            Dictionary with benchmark results
        """
        import time
        
        # Create dummy input
        dummy_input = torch.randn(1, *input_size).to(self.device)
        
        # Warmup
        print(f"Warming up ({warmup} runs)...")
        for _ in range(warmup):
            with torch.no_grad():
                _ = self.model(dummy_input)
        
        if self.device.type == 'cuda':
            torch.cuda.synchronize()
        
        # Benchmark
        print(f"Benchmarking ({num_runs} runs)...")
        times = []
        
        for _ in range(num_runs):
            if self.device.type == 'cuda':
                torch.cuda.synchronize()
            
            start = time.time()
            
            with torch.no_grad():
                _ = self.model(dummy_input)
            
            if self.device.type == 'cuda':
                torch.cuda.synchronize()
            
            times.append(time.time() - start)
        
        # Compute statistics
        times = np.array(times)
        
        h, w = input_size[1], input_size[2]
        scale = 4  # Assume 4x
        output_pixels = (h * scale) * (w * scale)
        
        results = {
            'mean_time_ms': np.mean(times) * 1000,
            'std_time_ms': np.std(times) * 1000,
            'min_time_ms': np.min(times) * 1000,
            'max_time_ms': np.max(times) * 1000,
            'fps': 1.0 / np.mean(times),
            'output_pixels': output_pixels,
            'output_resolution': f"{w*scale}x{h*scale}",
        }
        
        print(f"\nBenchmark Results ({num_runs} runs):")
        print(f"  Mean time: {results['mean_time_ms']:.2f} ± {results['std_time_ms']:.2f} ms")
        print(f"  FPS: {results['fps']:.2f}")
        print(f"  Resolution: {results['output_resolution']}")
        
        return results
    
    def get_model_info(self) -> Dict:
        """Get model information"""
        return {
            'device': str(self.device),
            'use_amp': self.use_amp,
            'parameters': sum(p.numel() for p in self.model.parameters()),
            'trainable_parameters': sum(p.numel() for p in self.model.parameters() if p.requires_grad),
        }


def quick_inference(
    checkpoint_path: str,
    input_path: str,
    output_path: str,
    model_type: str = 'span',
    device: str = 'cuda',
) -> np.ndarray:
    """
    Quick inference function for single image.
    
    Args:
        checkpoint_path: Path to model checkpoint
        input_path: Path to input image
        output_path: Path to save output
        model_type: Model type
        device: Device to use
    
    Returns:
        Super-resolved image as numpy array
    """
    # Create engine
    engine = InferenceEngine.from_checkpoint(checkpoint_path, model_type, device)
    
    # Load image
    image = cv2.imread(input_path)
    if image is None:
        raise ValueError(f"Failed to load image: {input_path}")
    
    # Run inference
    sr_image = engine.run(image)
    
    # Save
    cv2.imwrite(output_path, sr_image)
    print(f"Saved to: {output_path}")
    
    return sr_image
