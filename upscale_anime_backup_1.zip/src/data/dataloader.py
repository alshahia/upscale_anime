"""
Universal DataLoader factory
Supports single and multi-dataset loading with configurable workers, batch size, etc.
Also supports video datasets with on-demand or pre-extraction modes.
"""
import torch
from torch.utils.data import DataLoader
from typing import Dict, Optional, List
import psutil
from pathlib import Path

try:
    from data.base import BaseDataset, DatasetFactory, MultiDataset
    from data.video_dataset import VideoDataset, TemporalDataset
    from data.video_extraction import extract_from_folder
except ImportError:
    from base import BaseDataset, DatasetFactory, MultiDataset
    from video_dataset import VideoDataset, TemporalDataset
    from video_extraction import extract_from_folder


def get_optimal_num_workers(data_cfg: dict, batch_size: int) -> int:
    """
    Auto-detect optimal num_workers based on system resources.
    
    Rules:
    - Use 4 workers per GPU as baseline
    - Cap at CPU cores - 2 (leave headroom)
    - Reduce if system RAM < 16GB
    - Account for gradient accumulation (need more workers)
    
    Args:
        data_cfg: Data configuration dict
        batch_size: Training batch size
        
    Returns:
        Optimal number of workers
    """
    import os
    import psutil
    
    # User override takes precedence (unless explicitly set to null/None)
    user_workers = data_cfg.get('num_workers')
    auto_tune = data_cfg.get('auto_tune_workers', True)
    
    if user_workers is not None and not auto_tune:
        return user_workers
    
    if not auto_tune and user_workers is not None:
        return user_workers
    
    # Detect resources
    cpu_cores = os.cpu_count() or 4
    num_gpus = torch.cuda.device_count() if torch.cuda.is_available() else 1
    ram_gb = psutil.virtual_memory().total / (1024**3)
    
    # Get gradient accumulation from training config (affects throughput needs)
    # Note: This is accessed via parent config, default to 1 if not available
    accumulation_steps = data_cfg.get('gradient_accumulation_steps', 1)
    
    # Calculate optimal workers
    workers_per_gpu = 4
    base_workers = workers_per_gpu * num_gpus
    
    # Scale up for gradient accumulation (need to keep GPU fed)
    if accumulation_steps > 1:
        base_workers = max(base_workers, int(base_workers * min(accumulation_steps, 4) / 2))
    
    # Cap by CPU cores (leave 2 cores for main process and system)
    max_workers = max(1, cpu_cores - 2)
    num_workers = min(base_workers, max_workers)
    
    # Reduce for limited RAM (each worker holds a copy of data)
    if ram_gb < 8:
        num_workers = min(num_workers, 2)
    elif ram_gb < 16:
        num_workers = min(num_workers, 4)
    
    # Hard cap at 16 workers (diminishing returns beyond this)
    num_workers = min(num_workers, 16)
    
    print(f"[DataLoader] Auto-tuned num_workers: {num_workers} "
          f"(GPUs: {num_gpus}, CPUs: {cpu_cores}, RAM: {ram_gb:.1f}GB, "
          f"Accum: {accumulation_steps}x)")
    
    return num_workers


class DataLoaderFactory:
    """
    Factory for creating DataLoaders from config.
    Handles dataset creation, multi-dataset weighting, and DataLoader setup.
    """
    
    @staticmethod
    def _handle_video_extraction(data_cfg: Dict, is_train: bool) -> Optional[str]:
        """
        Handle video extraction based on config.
        
        Returns:
            Path to extracted frames directory, or None if no video processing
        """
        video_cfg = data_cfg.get('video', {})
        
        if not video_cfg.get('enabled', False):
            return None
        
        # Determine video directory
        video_dir = video_cfg.get('video_dir', 'data/anime_vid')
        video_path = Path(video_dir)
        
        # Auto-detect if default path doesn't exist but alternate does
        if not video_path.exists() and video_dir == 'data/anime_vid':
            # Try to find videos in data folder
            data_root = Path(data_cfg.get('data_root', 'data'))
            for potential in ['anime_vid', 'videos', 'video']:
                alt_path = data_root / potential
                if alt_path.exists():
                    video_path = alt_path
                    break
        
        if not video_path.exists():
            print(f"Warning: Video directory not found: {video_path}")
            return None
        
        # Check for video files
        video_extensions = ('.mp4', '.avi', '.mkv', '.mov', '.webm')
        has_videos = any(
            list(video_path.glob(f'*{ext}')) or list(video_path.glob(f'*{ext.upper()}'))
            for ext in video_extensions
        )
        
        if not has_videos:
            print(f"Warning: No video files found in {video_path}")
            return None
        
        # Determine extraction mode
        extract_mode = video_cfg.get('extract_mode', 'pre')
        
        if extract_mode == 'pre':
            # Pre-extraction: extract all frames before training
            output_dir = Path(video_cfg.get('output_dir', 'data/anime_video_frames'))
            
            # Check if already extracted
            if output_dir.exists() and any(output_dir.glob('*.png')):
                print(f"Using pre-extracted frames from: {output_dir}")
                return str(output_dir)
            
            print(f"Pre-extracting frames from videos in: {video_path}")
            print(f"Output directory: {output_dir}")
            
            result = extract_from_folder(
                video_folder=video_path,
                output_dir=output_dir,
                extract_every_n_frames=video_cfg.get('extract_every_n_frames', 30),
                quality_threshold=video_cfg.get('quality_threshold', 0.7),
                remove_duplicates=video_cfg.get('remove_duplicates', True),
                min_resolution=(video_cfg.get('min_resolution', 720),) * 2
            )
            
            if result['success'] and result['total_extracted'] > 0:
                print(f"Extracted {result['total_extracted']} frames successfully")
                return str(output_dir)
            else:
                print(f"Warning: Frame extraction failed or produced no frames")
                return None
        
        elif extract_mode == 'on_demand':
            # Return video_dir to indicate on-demand mode
            return str(video_path)
        
        return None
    
    @staticmethod
    def create(config: Dict, is_train: bool = True) -> DataLoader:
        """
        Create DataLoader from config.
        
        Args:
            config: Configuration dict with 'data' and 'training' sections
            is_train: Whether this is for training (affects shuffle, drop_last)
        
        Returns:
            Configured DataLoader
        """
        data_cfg = config.get('data', {})
        train_cfg = config.get('training', {})
        
        # Handle video extraction if enabled
        video_result = DataLoaderFactory._handle_video_extraction(data_cfg, is_train)
        video_cfg = data_cfg.get('video', {})
        
        # Get dataset configurations
        dataset_configs = data_cfg.get('datasets', [])
        
        # Filter enabled datasets
        enabled_configs = [cfg for cfg in dataset_configs if cfg.get('enabled', True)]
        
        # Add video dataset if video processing returned a path
        if video_result:
            extract_mode = video_cfg.get('extract_mode', 'pre')
            
            if extract_mode == 'pre':
                # Add as regular image dataset
                video_dataset_cfg = {
                    'name': 'anime_video',
                    'weight': video_cfg.get('weight', 0.5),
                    'enabled': True,
                    'hr_dir': video_result,
                    'scale': data_cfg.get('scale', 4),
                    'crop_size': data_cfg.get('crop_size', 128),
                    'augment': data_cfg.get('augment', True) and is_train,
                    'degradation': data_cfg.get('degradation') if is_train else None,
                }
                enabled_configs.append(video_dataset_cfg)
            
            elif extract_mode == 'on_demand':
                # Will create VideoDataset separately
                pass
        
        if len(enabled_configs) == 0 and not (video_result and video_cfg.get('extract_mode') == 'on_demand'):
            raise ValueError("No enabled datasets found in config")
        
        # Create dataset(s)
        datasets = []
        
        # Create standard datasets
        if len(enabled_configs) == 1:
            datasets.append(DatasetFactory.create(enabled_configs[0]))
        elif len(enabled_configs) > 1:
            weights = [cfg.get('weight', 1.0) for cfg in enabled_configs]
            
            # Merge dataset configs with global data settings
            full_configs = []
            for cfg in enabled_configs:
                full_cfg = {
                    'scale': data_cfg.get('scale', 4),
                    'crop_size': data_cfg.get('crop_size', 128),
                    'augment': data_cfg.get('augment', True) and is_train,
                    'degradation': data_cfg.get('degradation') if is_train else None,
                    **cfg,
                }
                full_configs.append(full_cfg)
            
            datasets.append(DatasetFactory.create_multi_dataset(full_configs, weights))
        
        # Create VideoDataset for on-demand mode
        if video_result and video_cfg.get('extract_mode') == 'on_demand':
            video_dataset = VideoDataset(
                video_dir=video_result,
                scale=data_cfg.get('scale', 4),
                crop_size=data_cfg.get('crop_size', 128),
                augment=data_cfg.get('augment', True) and is_train,
                degradation=data_cfg.get('degradation') if is_train else None,
                extract_every_n_frames=video_cfg.get('extract_every_n_frames', 30),
                quality_threshold=video_cfg.get('quality_threshold', 0.7),
                remove_duplicates=video_cfg.get('remove_duplicates', True),
                min_resolution=(video_cfg.get('min_resolution', 720),) * 2,
                cache_size_gb=video_cfg.get('cache_size_gb', 10.0),
            )
            datasets.append(video_dataset)
        
        # Combine datasets if multiple
        if len(datasets) == 1:
            dataset = datasets[0]
        elif len(datasets) > 1:
            # Combine with weights
            weights = [1.0] * len(datasets)  # Equal weight for mixed sources
            dataset = MultiDataset(datasets, weights)
        else:
            raise ValueError("No datasets could be created")
        
        # Wrap with TemporalDataset if temporal training is enabled
        if video_cfg.get('temporal_training', False):
            frame_window = video_cfg.get('frame_window', 3)
            scene_threshold = video_cfg.get('scene_change_threshold', 0.3)
            print(f"[DataLoader] Enabling temporal training with frame_window={frame_window}")
            dataset = TemporalDataset(
                base_dataset=dataset,
                frame_window=frame_window,
                scene_change_threshold=scene_threshold,
            )
        
        # DataLoader parameters
        batch_size = train_cfg.get('batch_size', data_cfg.get('batch_size', 8))
        
        # Use auto-tuning for num_workers (or user override)
        num_workers = get_optimal_num_workers(data_cfg, batch_size)
        
        pin_memory = data_cfg.get('pin_memory', True)
        prefetch_factor = data_cfg.get('prefetch_factor', 2)
        persistent_workers = data_cfg.get('persistent_workers', True) and num_workers > 0
        
        # For small datasets, don't drop last batch to ensure we have data
        dataset_len = len(dataset) if hasattr(dataset, '__len__') else 0
        should_drop_last = is_train and dataset_len > batch_size * 2
        
        dataloader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=is_train,
            num_workers=num_workers,
            pin_memory=pin_memory,
            drop_last=should_drop_last,  # Only drop if we have enough data
            prefetch_factor=prefetch_factor if num_workers > 0 else None,
            persistent_workers=persistent_workers if num_workers > 0 else False,
        )
        
        return dataloader
    
    @staticmethod
    def create_train_val_loaders(config: Dict) -> tuple:
        """
        Create both training and validation DataLoaders.
        
        Returns:
            (train_loader, val_loader)
        """
        train_loader = DataLoaderFactory.create(config, is_train=True)
        
        # For validation, disable augmentation and use smaller batch
        val_config = config.copy()
        val_config['data']['augment'] = False
        val_config['training']['batch_size'] = config.get('training', {}).get('batch_size', 8)
        
        val_loader = DataLoaderFactory.create(val_config, is_train=False)
        
        return train_loader, val_loader


def build_dataloader(config: Dict, mode: str = 'train') -> DataLoader:
    """
    Convenience function to build dataloader.
    
    Args:
        config: Full config dict
        mode: 'train', 'val', or 'test'
    
    Returns:
        DataLoader
    """
    is_train = (mode == 'train')
    return DataLoaderFactory.create(config, is_train=is_train)
