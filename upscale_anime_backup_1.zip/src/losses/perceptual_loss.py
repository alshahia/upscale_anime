"""
Perceptual Loss using VGG features
Captures high-level image statistics and textures
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
from typing import List, Dict


class VGGPerceptualLoss(nn.Module):
    """
    VGG-based perceptual loss.
    Uses features from pre-trained VGG19.
    """
    
    def __init__(
        self,
        layers: List[str] = ["relu3_3"],
        weights: List[float] = None,
        loss_type: str = "l1",  # l1, l2, or cosine
        normalize: bool = True,
    ):
        super().__init__()
        
        # Load pre-trained VGG19
        vgg = models.vgg19(pretrained=True).features
        vgg.eval()
        
        # Disable gradients for VGG
        for param in vgg.parameters():
            param.requires_grad = False
        
        # Layer name mapping
        self.layer_name_mapping = {
            "relu1_1": 1,
            "relu1_2": 3,
            "relu2_1": 6,
            "relu2_2": 8,
            "relu3_1": 11,
            "relu3_2": 13,
            "relu3_3": 15,
            "relu3_4": 17,
            "relu4_1": 20,
            "relu4_2": 22,
            "relu4_3": 24,
            "relu4_4": 26,
            "relu5_1": 29,
            "relu5_2": 31,
            "relu5_3": 33,
            "relu5_4": 35,
        }
        
        # Validate layers
        for layer in layers:
            if layer not in self.layer_name_mapping:
                raise ValueError(f"Unknown layer: {layer}. Available: {list(self.layer_name_mapping.keys())}")
        
        self.layers = layers
        
        # Normalize weights
        if weights is None:
            weights = [1.0 / len(layers)] * len(layers)
        
        if len(weights) != len(layers):
            raise ValueError(f"Number of weights ({len(weights)}) must match number of layers ({len(layers)})")
        
        # Normalize weights to sum to 1
        total = sum(weights)
        self.weights = [w / total for w in weights]
        
        self.loss_type = loss_type
        self.normalize = normalize
        
        # Build feature extractor
        self.feature_extractor = self._build_feature_extractor(vgg, layers)
        
        # ImageNet normalization
        self.register_buffer('mean', torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer('std', torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))
    
    def _build_feature_extractor(self, vgg: nn.Module, layers: List[str]) -> nn.ModuleDict:
        """Build feature extractor for specified layers"""
        feature_extractor = nn.ModuleDict()
        
        # Sort layers by their index
        layer_indices = [(name, self.layer_name_mapping[name]) for name in layers]
        layer_indices.sort(key=lambda x: x[1])
        
        prev_idx = 0
        for name, idx in layer_indices:
            # Extract slice from prev_idx to idx
            feature_extractor[name] = nn.Sequential(*list(vgg[prev_idx:idx+1]))
            prev_idx = idx + 1
        
        return feature_extractor
    
    def normalize_input(self, x: torch.Tensor) -> torch.Tensor:
        """Normalize input to ImageNet statistics"""
        if x.min() < 0:  # Assume already normalized to [-1, 1] or [-0.5, 0.5]
            x = (x + 1) / 2  # Convert to [0, 1]
        
        # Normalize
        x = (x - self.mean) / self.std
        return x
    
    def extract_features(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Extract VGG features"""
        features = {}
        
        # Normalize
        if self.normalize:
            x = self.normalize_input(x)
        
        # Extract features sequentially
        for name in self.layers:
            x = self.feature_extractor[name](x)
            features[name] = x
        
        return features
    
    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        Compute perceptual loss.
        
        Args:
            pred: Predicted image [B, 3, H, W]
            target: Target image [B, 3, H, W]
        
        Returns:
            Perceptual loss
        """
        # Extract features
        pred_features = self.extract_features(pred)
        target_features = self.extract_features(target)
        
        # Compute loss for each layer
        loss = 0
        for i, layer in enumerate(self.layers):
            pf = pred_features[layer]
            tf = target_features[layer]
            
            # Ensure same size
            if pf.shape != tf.shape:
                pf = F.interpolate(pf, size=tf.shape[2:], mode='bilinear', align_corners=False)
            
            # Compute loss
            if self.loss_type == "l1":
                layer_loss = F.l1_loss(pf, tf)
            elif self.loss_type == "l2":
                layer_loss = F.mse_loss(pf, tf)
            elif self.loss_type == "cosine":
                layer_loss = 1 - F.cosine_similarity(pf.flatten(1), tf.flatten(1), dim=1).mean()
            else:
                raise ValueError(f"Unknown loss type: {self.loss_type}")
            
            loss += self.weights[i] * layer_loss
        
        return loss


class ResNetPerceptualLoss(nn.Module):
    """
    ResNet-based perceptual loss (alternative to VGG).
    Often better for structural information.
    """
    
    def __init__(
        self,
        layers: List[str] = ["layer2", "layer3", "layer4"],
        weights: List[float] = None,
        loss_type: str = "l1",
    ):
        super().__init__()
        
        # Load pre-trained ResNet50
        resnet = models.resnet50(pretrained=True)
        resnet.eval()
        
        for param in resnet.parameters():
            param.requires_grad = False
        
        self.layers = layers
        
        if weights is None:
            weights = [1.0 / len(layers)] * len(layers)
        self.weights = [w / sum(weights) for w in weights]
        
        self.loss_type = loss_type
        
        # Build feature extractor
        self.features = nn.ModuleDict({
            "layer1": nn.Sequential(resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool, resnet.layer1),
            "layer2": resnet.layer2,
            "layer3": resnet.layer3,
            "layer4": resnet.layer4,
        })
        
        # ImageNet normalization
        self.register_buffer('mean', torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer('std', torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))
    
    def normalize_input(self, x: torch.Tensor) -> torch.Tensor:
        """Normalize input to ImageNet statistics"""
        if x.min() < 0:
            x = (x + 1) / 2
        
        x = (x - self.mean) / self.std
        return x
    
    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """Compute ResNet perceptual loss"""
        pred = self.normalize_input(pred)
        target = self.normalize_input(target)
        
        loss = 0
        
        for i, layer in enumerate(self.layers):
            pred = self.features[layer](pred)
            target = self.features[layer](target)
            
            if self.loss_type == "l1":
                layer_loss = F.l1_loss(pred, target)
            elif self.loss_type == "l2":
                layer_loss = F.mse_loss(pred, target)
            else:
                layer_loss = 1 - F.cosine_similarity(pred.flatten(1), target.flatten(1), dim=1).mean()
            
            loss += self.weights[i] * layer_loss
        
        return loss


class PerceptualLossFactory:
    """Factory for creating perceptual loss functions"""
    
    @staticmethod
    def create(loss_type: str = "vgg", **kwargs) -> nn.Module:
        """
        Create perceptual loss.
        
        Args:
            loss_type: 'vgg', 'resnet', or 'none'
            **kwargs: Additional arguments for loss constructor
        
        Returns:
            Perceptual loss module
        """
        if loss_type.lower() == "vgg":
            return VGGPerceptualLoss(**kwargs)
        elif loss_type.lower() == "resnet":
            return ResNetPerceptualLoss(**kwargs)
        elif loss_type.lower() == "none" or loss_type.lower() == "disabled":
            return nn.Module()  # Dummy module
        else:
            raise ValueError(f"Unknown perceptual loss type: {loss_type}")
