#!/usr/bin/env python3
"""
Inference script for upscaling single images or batches
"""
import sys
import argparse
import torch
import cv2
import numpy as np
from pathlib import Path
from tqdm import tqdm

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from models.span import create_span_model
from utils.config import Config


def load_model(checkpoint_path: str, config_path: str = None, device: str = 'cuda'):
    """Load trained model from checkpoint"""
    device = torch.device(device if torch.cuda.is_available() else 'cpu')
    
    # Load config if provided
    if config_path:
        config = Config.load(config_path)
        model = create_span_model(config.get('model', {}))
    else:
        # Default model config
        model = create_span_model({'type': 'span', 'scale': 4})
    
    # Load checkpoint (weights_only=False needed for checkpoints with Config objects)
    try:
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=True)
    except Exception:
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    
    if 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
    elif 'state_dict' in checkpoint:
        model.load_state_dict(checkpoint['state_dict'])
    else:
        model.load_state_dict(checkpoint)
    
    model = model.to(device)
    model.eval()
    
    print(f"Loaded model from {checkpoint_path}")
    print(f"Model parameters: {model.count_parameters():,}")
    
    return model, device


def preprocess_image(image_path: str, scale: int = 4) -> torch.Tensor:
    """Load and preprocess image for inference"""
    # Read image
    img = cv2.imread(image_path, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Failed to load image: {image_path}")
    
    # Convert BGR to RGB
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    # Convert to tensor [C, H, W], float32, [0, 1]
    img = torch.from_numpy(img.transpose(2, 0, 1)).float() / 255.0
    
    # Add batch dimension
    img = img.unsqueeze(0)
    
    return img


def postprocess_image(tensor: torch.Tensor) -> np.ndarray:
    """Convert model output to numpy image"""
    # Remove batch dimension and clamp
    tensor = tensor.squeeze(0).clamp(0, 1)
    
    # Convert to numpy [H, W, C], uint8
    img = (tensor.permute(1, 2, 0).cpu().numpy() * 255).astype(np.uint8)
    
    # Convert RGB to BGR for OpenCV
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    
    return img


def inference(model, lr_image: torch.Tensor, device: torch.device, use_amp: bool = True) -> torch.Tensor:
    """Run inference on a single image"""
    lr_image = lr_image.to(device)
    
    with torch.no_grad():
        with torch.cuda.amp.autocast(enabled=use_amp and device.type == 'cuda'):
            output = model(lr_image)
    
    return output


def main():
    parser = argparse.ArgumentParser(description='Super-Resolution Inference')
    parser.add_argument('--checkpoint', '-c', type=str, required=True,
                      help='Path to model checkpoint')
    parser.add_argument('--input', '-i', type=str, required=True,
                      help='Input image path or directory')
    parser.add_argument('--output', '-o', type=str, required=True,
                      help='Output image path or directory')
    parser.add_argument('--config', type=str,
                      help='Path to model config YAML')
    parser.add_argument('--scale', type=int, default=4,
                      help='Upsampling factor')
    parser.add_argument('--device', type=str, default='cuda',
                      choices=['cuda', 'cpu'],
                      help='Device for inference')
    parser.add_argument('--batch', action='store_true',
                      help='Process directory of images')
    parser.add_argument('--fp16', action='store_true',
                      help='Use FP16 for faster inference')
    
    args = parser.parse_args()
    
    # Load model
    print("Loading model...")
    model, device = load_model(args.checkpoint, args.config, args.device)
    
    input_path = Path(args.input)
    output_path = Path(args.output)
    
    if args.batch or input_path.is_dir():
        # Batch processing
        if not input_path.is_dir():
            print(f"Error: --batch specified but input is not a directory: {input_path}")
            return
        
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Get all images
        image_extensions = {'.png', '.jpg', '.jpeg', '.bmp', '.tiff'}
        image_files = [f for f in input_path.iterdir() 
                      if f.suffix.lower() in image_extensions]
        
        print(f"Found {len(image_files)} images to process")
        
        for img_path in tqdm(image_files, desc="Processing"):
            try:
                # Load
                lr = preprocess_image(str(img_path), args.scale)
                
                # Inference
                sr = inference(model, lr, device, args.fp16)
                
                # Save
                output_img = postprocess_image(sr)
                output_file = output_path / f"{img_path.stem}_sr{img_path.suffix}"
                cv2.imwrite(str(output_file), output_img)
                
            except Exception as e:
                print(f"Error processing {img_path}: {e}")
                continue
        
        print(f"\nResults saved to: {output_path}")
        
    else:
        # Single image processing
        print(f"Processing: {input_path}")
        
        # Load
        lr = preprocess_image(str(input_path), args.scale)
        
        # Inference
        import time
        start = time.time()
        sr = inference(model, lr, device, args.fp16)
        elapsed = time.time() - start
        
        # Save
        output_img = postprocess_image(sr)
        cv2.imwrite(str(output_path), output_img)
        
        # Report
        input_h, input_w = lr.shape[2:]
        output_h, output_w = sr.shape[2:]
        print(f"\nInput: {input_w}x{input_h}")
        print(f"Output: {output_w}x{output_h}")
        print(f"Inference time: {elapsed:.3f}s")
        print(f"Saved to: {output_path}")


if __name__ == '__main__':
    main()
