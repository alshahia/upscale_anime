#!/usr/bin/env python3
"""
Main training script for Anime Super-Resolution
Supports: Model A (NTIRE+MTKD+FAKD), Model B (Mamba-PAN), Ensemble training
"""
import sys
import argparse
import torch
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from utils.config import Config
from data.dataloader import build_dataloader
from training import TrainingOrchestrator, create_orchestrator


def parse_config_override(value: str):
    """Parse config override value to appropriate type"""
    # Try bool first
    if value.lower() in ('true', 'yes', 'on'):
        return True
    if value.lower() in ('false', 'no', 'off'):
        return False
    # Try int
    try:
        return int(value)
    except ValueError:
        pass
    # Try float
    try:
        return float(value)
    except ValueError:
        pass
    # Return as string
    return value


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='Train Anime Super-Resolution Model')
    
    # Config
    parser.add_argument('--config', '-c', type=str, required=True,
                      help='Path to config YAML file')
    parser.add_argument('--mode', '-m', type=str,
                      choices=['model_a', 'model_b', 'both_parallel', 'both_sequential', 'ensemble', 'full'],
                      help='Training mode override')
    
    # Training control
    parser.add_argument('--resume', '-r', type=str,
                      help='Resume from checkpoint path')
    parser.add_argument('--device', type=str, default='cuda',
                      help='Device (cuda/cpu)')
    parser.add_argument('--num-workers', type=int,
                      help='Number of dataloader workers')
    parser.add_argument('--batch-size', type=int,
                      help='Override batch size')
    parser.add_argument('--epochs', type=int,
                      help='Override number of epochs')
    parser.add_argument('--lr', type=float,
                      help='Override learning rate')
    
    # Logging
    parser.add_argument('--dry-run', action='store_true',
                      help='Validate config and exit')
    parser.add_argument('--tensorboard', action='store_true',
                      help='Enable TensorBoard logging')
    parser.add_argument('--verbose', '-v', action='store_true',
                      help='Verbose output')
    
    # Parse known args first
    args, unknown = parser.parse_known_args()
    
    # Process unknown args as config overrides (--key.subkey value)
    args.config_overrides = {}
    i = 0
    while i < len(unknown):
        arg = unknown[i]
        if arg.startswith('--'):
            key = arg[2:]  # Remove '--'
            # Get value if next arg exists and isn't another flag
            if i + 1 < len(unknown) and not unknown[i + 1].startswith('--'):
                value = parse_config_override(unknown[i + 1])
                args.config_overrides[key] = value
                i += 2
            else:
                # Boolean flag without value
                args.config_overrides[key] = True
                i += 1
        else:
            i += 1
    
    return args


def validate_config(config: Config) -> bool:
    """Validate configuration"""
    print("Validating configuration...")
    
    try:
        config.validate()
        
        # Check data paths
        data_configs = config.get('data.datasets', [])
        for dataset_cfg in data_configs:
            if dataset_cfg.get('enabled', True):
                hr_dir = dataset_cfg.get('hr_dir')
                if hr_dir:
                    hr_path = Path(hr_dir)
                    if not hr_path.exists():
                        print(f"Warning: HR directory does not exist: {hr_dir}")
        
        # Check CUDA availability
        device = config.get('training.device', 'cuda')
        if device == 'cuda' and not torch.cuda.is_available():
            print("Warning: CUDA not available, switching to CPU")
            config.set('training.device', 'cpu')
        
        # Estimate VRAM usage
        # Check multiple locations for batch_size (training.stage1, training.stage2, data, or root training)
        batch_size = (
            config.get('training.stage1.batch_size') or
            config.get('training.stage2.batch_size') or
            config.get('training.batch_size') or
            config.get('data.batch_size') or
            8
        )
        model_type = config.get('model.type', 'span')
        
        if model_type == 'mamba_pan':
            est_vram = batch_size * 0.9  # ~0.9GB per sample for Mamba
        else:
            est_vram = batch_size * 0.4  # ~0.4GB per sample for SPAN
        
        print(f"Estimated VRAM usage: {est_vram:.1f}GB (batch_size={batch_size})")
        
        if torch.cuda.is_available():
            total_vram = torch.cuda.get_device_properties(0).total_memory / 1e9
            print(f"Available VRAM: {total_vram:.1f}GB")
            
            if est_vram > total_vram * 0.9:
                print(f"Warning: Estimated VRAM ({est_vram:.1f}GB) may exceed available VRAM ({total_vram:.1f}GB)")
                print("Consider reducing batch_size or enabling gradient_checkpointing")
        
        print("Configuration validation passed!")
        return True
        
    except Exception as e:
        print(f"Configuration validation failed: {e}")
        return False


def estimate_training_time(config: Config) -> str:
    """Estimate training time"""
    stage1_epochs = config.get('training.stage1.epochs', 0)
    stage2_epochs = config.get('training.stage2.epochs', 0)
    total_epochs = stage1_epochs + stage2_epochs
    
    # Rough estimate: ~2-5 minutes per epoch on RTX 4000
    min_time = total_epochs * 2
    max_time = total_epochs * 5
    
    return f"{min_time}-{max_time} minutes ({min_time/60:.1f}-{max_time/60:.1f} hours)"


def main():
    """Main entry point"""
    args = parse_args()
    
    print(f"\n{'='*60}")
    print(f"Anime Super-Resolution Training")
    print(f"{'='*60}\n")
    
    # Load config
    print(f"Loading config: {args.config}")
    try:
        config = Config.load(args.config)
    except Exception as e:
        print(f"Error loading config: {e}")
        sys.exit(1)
    
    # Apply config overrides from CLI (e.g., --data.video.enabled true)
    if args.config_overrides:
        print("Applying config overrides:")
        for key, value in args.config_overrides.items():
            print(f"  {key} = {value}")
            config.set(key, value)
    
    # Merge CLI arguments
    config.merge_args(args)
    
    # Set training mode from CLI if provided
    if args.mode:
        config.set('training.mode', args.mode)
    
    # Handle batch_size override - set in both training and data sections
    if args.batch_size is not None:
        config.set('training.batch_size', args.batch_size)
        config.set('data.batch_size', args.batch_size)
    
    # Handle epochs override - map to both stage1 and stage2
    if args.epochs is not None:
        stage1_cfg = config.get('training.stage1', {})
        stage2_cfg = config.get('training.stage2', {})
        if stage1_cfg.get('enabled', False):
            config.set('training.stage1.epochs', args.epochs)
        if stage2_cfg.get('enabled', False):
            config.set('training.stage2.epochs', args.epochs)
    
    # Dry run: validate and exit
    if args.dry_run:
        print("\nDry run mode - validating configuration...")
        if validate_config(config):
            print("\nConfig is valid! Estimated training time:", estimate_training_time(config))
            print("\nTo start training, run without --dry-run")
        else:
            print("\nConfig validation failed!")
            sys.exit(1)
        return
    
    # Validate config
    if not validate_config(config):
        print("\nFix configuration errors before training.")
        sys.exit(1)
    
    # Print training info
    mode = config.get('training.mode', 'model_a')
    print(f"\nTraining mode: {mode}")
    print(f"Model: {config.get('model.name', 'unknown')}")
    print(f"Estimated time: {estimate_training_time(config)}")
    print(f"Device: {config.get('training.device', 'cuda')}")
    print()
    
    # Build dataloaders
    print("Building dataloaders...")
    try:
        train_loader = build_dataloader(config, mode='train')
        val_loader = build_dataloader(config, mode='val')
        print(f"Train batches: {len(train_loader)}")
        print(f"Val batches: {len(val_loader)}")
    except FileNotFoundError as e:
        print(f"\n❌ Error: {e}")
        print("\nTo fix this, you can:")
        print("1. Create test data:")
        print(f"   python scripts/create_test_data.py --output data/test_hr --num-images 10")
        print("\n2. Update config to point to your data:")
        print(f"   python scripts/train.py --config {args.config} --data.datasets.0.hr_dir 'path/to/your/data'")
        print("\n3. Prepare your dataset:")
        print(f"   python scripts/prepare_data.py --input path/to/videos --output data/processed --mode full")
        sys.exit(1)
    except ValueError as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error building dataloaders: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # Create orchestrator
    print(f"\nCreating training orchestrator for mode: {mode}...")
    
    try:
        orchestrator = create_orchestrator(config)
        orchestrator.setup()
    except ValueError as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)
    except NotImplementedError as e:
        print(f"\n⚠️  {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error setting up orchestrator: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # Start training
    print(f"\n{'='*60}")
    print(f"Starting training")
    print(f"{'='*60}\n")
    
    try:
        orchestrator.train(train_loader, val_loader)
        orchestrator.save_metadata()
    except KeyboardInterrupt:
        print("\n\nTraining interrupted by user.")
        print("Attempting to save checkpoint...")
        try:
            orchestrator.save_metadata()
            print("Metadata saved. Exiting.")
        except:
            print("Could not save metadata. Exiting.")
        sys.exit(0)
    except Exception as e:
        print(f"\n\nError during training: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    print(f"\n{'='*60}")
    print(f"Training complete!")
    print(f"{'='*60}\n")


if __name__ == '__main__':
    main()
